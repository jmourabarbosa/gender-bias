import pandas as pd
import numpy as np

pd.options.mode.chained_assignment = None  # default='warn'

import statsmodels.api as sm
import scipy.stats as st
from scipy.stats import pearsonr

import matplotlib.pyplot as plt
import seaborn as sns

from scripts import load_data

custom_params = {"axes.spines.right": False, 
                 "axes.spines.top": False,
                 "figure.figsize":(12,8),
                 'xtick.bottom': True,
                 'ytick.left': True}
sns.set_theme(style="white", rc=custom_params)


def create_push_pull_df(df, groupby_cols=["gender"]):
    """
    Group responses by groupby_cols and their responses to the push/pull question (positive_negative)
    """
    push_pull_df = df[df.positive_negative.isin(["Push", "Pull", "Both"])]
    career_age_means = push_pull_df.groupby(groupby_cols)["positive_negative"].value_counts(normalize=True)
    final_df = career_age_means.reset_index(name="percent")
    return final_df

def err_bar_proportion(df_subset, col, p):
    """
    Compute error bars for a particular subgroup of respondents (df_subset) 
    on a particular value (p) of a variable (col) 
    """
    import statsmodels.stats.proportion as stp
    ci_lower, ci_upper = stp.proportion_confint(
        count = len(df_subset[df_subset[col] == p]),
        nobs = len(df_subset),
        alpha=0.05) 
    
    CI_length = (ci_upper - ci_lower) / 2 # this is the +/-, y_err
    return CI_length 

def make_regression_features(df_regression):
    """
    Make features for the logistic regression.
    """
    df_regression['is_female'] = np.where(df_regression.gender == "Woman", 1, 0)
    df_regression['is_POC'] = np.where(df_regression.BIPOC == 1, 1, 0)
    df_regression['is_underrep'] = np.where(df_regression.underrepresented == 1, 1, 0)
    df_regression['is_WOC'] = np.where(((df_regression.BIPOC == 1) & (df_regression.gender == "Woman")), 1, 0)
    
    df_regression['is_push'] = np.where(df_regression.positive_negative == "Push", 1, 0) 
    df_regression['is_pull'] = np.where(df_regression.positive_negative == "Pull", 1, 0) 
    df_regression['is_both'] = np.where(df_regression.positive_negative == "Both", 1, 0) 
    df_regression['would_not_leave'] = np.where(df_regression.positive_negative == "I would not consider leaving", 1, 0) 
    
    df_regression['prestige_decile'] = df_regression["overall_inst_rank"]/1
    df_regression['career_age_decade'] = df_regression["career_age"]/10
    
    df_regression['is_STEM'] = np.where(df_regression.STEM == "STEM", 1, 0)

    df_regression['is_mother_kids_under_18'] = np.where(((df_regression.gender == "Woman") &
                                                        (df_regression.kids_under_18 == 1)), 1, 0)
    return df_regression
    
def run_regression(df_regression, y_col, fixed_domain=False):
    """
    Run one regression adjusting for gender, career age, prestige and STEM, 
    predicting either "is_push" or "is_pull" (y_col)
    with the option to add fixedd effects for domain
    """
    X = df_regression[['is_female',
                       'career_age_decade',
                       'overall_inst_decile',
                       'is_STEM'
                      ]]
    
    X = sm.add_constant(X)
    
    if fixed_domain:
        X = pd.concat((X, pd.get_dummies(df_regression['domain'], drop_first=True)), axis=1)

    y = df_regression[[y_col]]

    # building the model and fitting the data
    results = sm.Logit(y, X.astype(float)).fit(disp=0)
    return results
    
# PLOTTING    
def plot_fig3a(df, group_col, age_order, age_index, y_col, 
                                    palette, err=True, 
                                    area_df=[], area="", frac=0, pad=True):  
    df = df[df.positive_negative == y_col]
    fig, ax = plt.subplots(figsize=(5,4))

    for g in set(df[group_col]):
        women_df = df[(df.gender == "Woman") & (df[group_col] == g)]
        men_df = df[(df.gender == "Man") & (df[group_col] == g)]

        women_df["age_group"] = pd.Categorical(women_df["age_group"], categories=age_order, ordered=True)
        men_df["age_group"] = pd.Categorical(men_df["age_group"], categories=age_order, ordered=True)
        women_df = women_df.sort_values("age_group", ascending=True)
        men_df = men_df.sort_values("age_group", ascending=True)

        women_df["age_index"] = women_df["age_group"].map(age_index)
        men_df["age_index"] = men_df["age_group"].map(age_index)
        
        if g == "STEM":
            plt.plot(women_df["age_group"], women_df["percent"], color="teal", linestyle="solid", linewidth=3)
        else:
            plt.plot(women_df["age_group"], women_df["percent"], color="#7de3e3", linestyle="solid", linewidth=3, zorder=10)
             
        plt.plot(men_df["age_group"], men_df["percent"], color={"STEM":"#4d4d4f", "Non-STEM":"lightgrey"}[g], linestyle="solid", linewidth=3)
    
        sns.scatterplot(ax=ax, data=women_df, x="age_group", y="percent",
                        hue=group_col, palette={"STEM":"teal", "Non-STEM":"#7de3e3"}, #"#8fe3e3"}, 
                        marker="^", s=90, edgecolor="black", linewidth=0.2,
                        zorder=20)
        sns.scatterplot(ax=ax, data=men_df, x="age_group", y="percent",
                        hue=group_col, palette={"STEM":"#4d4d4f", "Non-STEM":"lightgrey"}, 
                        marker="o", s=70, edgecolor="black", linewidth=0.2,
                        zorder=20)
        
        if err:
            # plot max line
            sns.lineplot(ax=ax, data=women_df, x="age_group", y="ci_upper", color={"STEM":"teal", "Non-STEM":"paleturquoise"}[g],
                         linewidth=0.25, alpha=0.2)
            sns.lineplot(ax=ax, data=men_df, x="age_group", y="ci_upper", color={"STEM":"#4d4d4f", "Non-STEM":"lightgrey"}[g],
                         linewidth=0.25, alpha=0.2)

            # plot min line
            sns.lineplot(ax=ax, data=women_df, x="age_group", y="ci_lower", color={"STEM":"teal", "Non-STEM":"paleturquoise"}[g],
                         linewidth=0.25, alpha=0.2)
            sns.lineplot(ax=ax, data=men_df, x="age_group", y="ci_lower", color={"STEM":"#4d4d4f", "Non-STEM":"lightgrey"}[g],
                         linewidth=0.25, alpha=0.2)

            # fill between
            if g == "STEM":
                ax.fill_between(women_df["age_group"], women_df["ci_upper"], women_df["percent"], color="teal", alpha=0.15)
                ax.fill_between(women_df["age_group"], women_df["percent"], women_df["ci_lower"], color="teal", alpha=0.15)
            else:
                ax.fill_between(women_df["age_group"], women_df["ci_upper"], women_df["percent"], color="paleturquoise", alpha=0.4)
                ax.fill_between(women_df["age_group"], women_df["percent"], women_df["ci_lower"], color="paleturquoise", alpha=0.4)
            
            ax.fill_between(men_df["age_group"], men_df["ci_upper"], men_df["percent"], color={"STEM":"#4d4d4f", "Non-STEM":"lightgrey"}[g], alpha=0.2)
            ax.fill_between(men_df["age_group"], men_df["percent"], men_df["ci_lower"], color={"STEM":"#4d4d4f", "Non-STEM":"lightgrey"}[g], alpha=0.2)

    if len(area_df) > 0:
        print(area)
        area_df = area_df[area_df.positive_negative == y_col]
        women_df = area_df[(area_df.gender == "Woman") & (area_df["AA_area"] == area)]
        men_df = area_df[(area_df.gender == "Man") & (area_df["AA_area"] == area)]

        women_df["age_group"] = pd.Categorical(women_df["age_group"], categories=age_order, ordered=True)
        men_df["age_group"] = pd.Categorical(men_df["age_group"], categories=age_order, ordered=True)
        women_df = women_df.sort_values("age_group", ascending=True)
        men_df = men_df.sort_values("age_group", ascending=True)

        women_df["age_index"] = women_df["age_group"].map(age_index)
        men_df["age_index"] = men_df["age_group"].map(age_index)
        
        sns.lineplot(ax=ax, data=women_df, x="age_group", y="percent", color="turquoise", linestyle="dashed", linewidth=3)
        sns.lineplot(ax=ax, data=men_df, x="age_group", y="percent", color="grey", linestyle="dashed", linewidth=3)
    
        sns.scatterplot(ax=ax, data=women_df, x="age_group", y="percent", color="turquoise")
        sns.scatterplot(ax=ax, data=men_df, x="age_group", y="percent", color="grey")
    
    plt.ylim([0, 0.7])
    plt.legend([],[], frameon=False)
    
    ax.set_xticks([i for i in range(len(age_order))])
    ax.set_xticklabels(age_order, fontsize=13)
    ax.set_yticklabels([0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7], fontsize=13)
    
    ax.set_xlabel(r"Career age, $t$ (years since PhD)", fontsize=17)
    if y_col == "Push":
        ax.set_ylabel("Fraction who felt pushed", fontsize=17)
    
    if y_col == "Pull":
        ax.set_ylabel("Fraction who felt pulled", fontsize=17)
        
    plt.tight_layout()
    fig.savefig('figures/fig3a_' + y_col + '.pdf', dpi=300)
    
def plot_fig3c(results, y_col):
    """
    Takes in results of regression model and returns a plot of 
    the coefficients with 95% confidence intervals.
    """
    # Create dataframe of results summary 
    coef_df = pd.DataFrame(results.summary().tables[1].data)
    coef_df.columns = coef_df.iloc[0]
    coef_df=coef_df.drop(0)
    coef_df = coef_df.set_index(coef_df.columns[0])
    coef_df = coef_df.astype(float)

    # Get errors (coef - lower bound of conf interval)
    errors = coef_df['coef'] - coef_df['[0.025']
    coef_df['errors'] = errors
    
    coef_df = coef_df.drop(['const'])
    coef_df = coef_df.sort_values(by=['coef'])

    # Color by significance
    coef_df["sig"] = np.where(coef_df["P>|z|"] < 0.06, True, False) 
    
    variables = list(coef_df.index.values)
    
    rename_variables = {"is_female": "Woman",
                        "is_STEM": "STEM",
                        "overall_inst_decile": "Prestige decile",
                        "career_age_decade": "Career age"}
    
    coef_df['variables'] = [rename_variables[v] for v in variables]
    coef_df['variables'] = pd.Categorical(coef_df['variables'], ["Prestige decile", "STEM", "Career age", "Woman"])
    coef_df = coef_df.sort_values("variables")
    
    fig, ax = plt.subplots(figsize=(5, 2.5))
    
    # Error bars
    if y_col == "is_push":
        plt.errorbar(coef_df["coef"], coef_df["variables"], xerr=coef_df["errors"], ls='none',
                     ecolor=["black", "grey", "black", "black"])
        plt.scatter(coef_df["coef"], coef_df["variables"], s=50, 
                    c=["black", "white", "black", "black"], edgecolors=["black", "grey", "black", "black"], 
                    linewidths=1, zorder=10)
    else:
        plt.errorbar(coef_df["coef"], coef_df["variables"], xerr=coef_df["errors"], ls='none', color="black")
        plt.scatter(coef_df["coef"], coef_df["variables"], s=50, color="black", linewidths=1, zorder=10)
   
    ax.set_xlabel('Coefficient',fontsize=14)
    ax.set_yticklabels(["Prestige decile", "STEM", r"Career age, $t$", "Woman"],fontsize=14)
    ax.axvline(x=0, linestyle='--', color='black', linewidth=1)
    ax.set_xlim([-0.6, 0.6])
    
    if y_col == "is_push":
        ax.set_title("Left or would leave due to a push", y=1.05, fontsize=14)
    else:
        ax.set_title("Left or would leave due to a pull", y=1.05, fontsize=14)
    
    plt.tight_layout()
    fig.savefig("figures/fig3c_" + y_col + ".pdf", dpi=300)
    

if __name__ == "__main__":
    # Load survey data
    df = load_data.load_survey()
    
    # Fraction who felt pushed/pulled out of their jobs
    df = df[(df.career_age > 0) & (df.career_age <= 40)]
    print(len(df))

    age_groups = {1: '1-10', 2: '1-10', 3: '1-10', 4: '1-10', 5:'1-10',
                  6: '1-10', 7: '1-10', 8: '1-10', 9: '1-10', 10: '1-10',
                  11: '11-20', 12: '11-20', 13: '11-20', 14: '11-20', 15: '11-20',
                  16: '11-20', 17: '11-20', 18: '11-20', 19: '11-20', 20: '11-20',
                  21: '21-30', 22: '21-30', 23: '21-30', 24: '21-30', 25: '21-30',
                  26: '21-30', 27: '21-30', 28: '21-30', 29: '21-30', 30: '21-30',
                  31: '31-40', 32: '31-40', 33: '31-40', 34: '31-40', 35: '31-40',
                  36: '31-40', 37: '31-40', 38: '31-40', 39: '31-40', 40: '31-40'}

    df["age_group"] = df["career_age"].map(age_groups)
    df = df[df.positive_negative.isin(["Push", "Pull", "Both"])]
    push_pull_df = create_push_pull_df(df, groupby_cols=["gender","STEM","age_group"])
    
    def compute_cis(row):
        s = row['STEM']
        g = row['gender']
        a = row['age_group']
        p = row['positive_negative'] 

        df_subset = df[(df.STEM == s) & (df.gender == g) & (df.age_group == a)]   
        ci = err_bar_proportion(df_subset, col='positive_negative', p=p)

        return ci
    
    push_pull_df['ci'] = push_pull_df.apply(compute_cis, axis=1)
    push_pull_df['ci_upper'] = push_pull_df["percent"] + push_pull_df["ci"]
    push_pull_df['ci_lower'] = push_pull_df["percent"] - push_pull_df["ci"]
    
    # Plot Figure 3A & B
    age_order = ['1-10', '11-20', '21-30', '31-40']
    age_index = {'1-10': 1, '11-20': 2, '21-30': 3, '31-40': 4}

    plot_fig3a(push_pull_df, group_col="STEM", 
               age_order=age_order, age_index=age_index, 
               y_col="Push", palette={})
    
    plot_fig3a(push_pull_df, group_col="STEM", 
               age_order=age_order, age_index=age_index, 
               y_col="Pull", palette={})
    
    # Set up the regression
    df_regression = df
    
    # Remove people who would not leave
    df_regression = df_regression[(df_regression.positive_negative != "I would not consider leaving") &
                                  (df_regression.positive_negative != "Retire")]
    
    df_regression = df_regression[df_regression.group != "switched"]
    
    df_regression = make_regression_features(df_regression)
    
    m_push = run_regression(df_regression, y_col="is_push")
    m_pull = run_regression(df_regression, y_col="is_pull")
    
    # Plot figures 3C & D
    plot_fig3c(m_push, y_col="is_push")
    plot_fig3c(m_pull, y_col="is_pull")
    
    