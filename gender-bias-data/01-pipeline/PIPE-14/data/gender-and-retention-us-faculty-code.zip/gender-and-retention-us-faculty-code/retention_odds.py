import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import statsmodels.api as sm

from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib.patches as mpatches
from matplotlib import rc
from matplotlib.transforms import blended_transform_factory
from matplotlib.patches import ConnectionPatch

import seaborn as sns

rc("font",**{"family":"sans-serif","sans-serif":["Helvetica"]})

import warnings
warnings.simplefilter(action="ignore", category=FutureWarning)


def drop_missing_data(df):
    """
    Drop person-years that are missing prestige (SpringRank), PhD degree year (DegreeYear) 
    or PhD country (CountryName) data because we can't have missing variables in the regression
    """
    missing_prestige_rank = (df[df["SpringRank"].isna()]).index
    df_missing_prestige_rank = df.loc[missing_prestige_rank].copy()

    missing_degree_year = (df[df["DegreeYear"].isna()]).index
    df_missing_degree_year = df.loc[missing_degree_year].copy()

    missing_degree_country = (df[df["CountryName"].isna()]).index
    df_missing_degree_country = df.loc[missing_degree_country].copy()
    
    print("Dropping",len(missing_prestige_rank),"person-years that are missing prestige rank.")
    df = df.drop(missing_prestige_rank)

    missing_degree_year = (df[df["DegreeYear"].isna()]).index
    print("Dropping",len(missing_degree_year),"person-years that are missing degree year.")
    df = df.drop(missing_degree_year)

    missing_degree_country = (df[df["CountryName"].isna()]).index
    print("Dropping",len(missing_degree_country),"person-years that are missing degree country.")
    df = df.drop(missing_degree_country)
    
    return df

def run_one_regression(df_regression, rank_index, regression_vars, 
                       event="is_attrition", 
                       taxonomy_name="Academia", taxonomy_level="Umbrella",
                       fixed_field=False, includes_controls=False):
    """
    Run one logistic regression model on person-years of the given rank, taxonomy 
    (e.g., "Academia", "STEM", or "Natural Sciences"), and event ("is_attrition" or "is_promotion")
    """
    if event == "is_promotion":
        # remove faculty that joined or left from the set of people who could have been promoted
        df_regression = df_regression[(df_regression["event"] != "inflow") & (df_regression["event"] != "attrition")]
        
    df_regression = df_regression[(df_regression["Rank"]==rank_index)].drop_duplicates(subset = ["PersonId","Year"])

    # defining the dependent and independent variables
    if includes_controls:
        X = df_regression[regression_vars]
    else:
        X = df_regression[["is_female"]]

    if fixed_field:
        # add fixed effects for Field
        X = pd.concat((X, pd.get_dummies(df_regression["Field"], drop_first=True)), axis=1)

    X = sm.add_constant(X)
    y = df_regression[[event]]

    # building the model and fitting the data
    log_reg = sm.Logit(y, X).fit(disp=0)
    odds_female = np.exp(log_reg.params["is_female"])

    results_row = pd.DataFrame([{
        "Rank":rank_index,
        "event":event,
        "includes_controls":includes_controls,
        "model":log_reg,
         taxonomy_level:taxonomy_name,
        "odds_lower_95":np.exp(log_reg.conf_int().loc["is_female",0]),
        "odds":odds_female,
        "odds_upper_95":np.exp(log_reg.conf_int().loc["is_female",1]),
        "p":log_reg.pvalues["is_female"],
        "n":len(df_regression),
        "n_unique_people":len(df_regression.drop_duplicates(subset=["PersonId"]))
    }])

    return results_row

def make_regression_features(df):
    # Make features
    df["is_attrition"] = df.event == "attrition"
    df["is_promotion"] = df.event == "promotion"
    df["is_female"] = (df.Gender == "Female").astype(int)
    df["is_us_degree"] = (df.CountryName == "United States").astype(int)
    df["is_female_x_us_degree"] = df["is_female"] * df["is_us_degree"] 
    df["prestige_decile"] = df["ZeroToOneRank"]/0.1
    df["career_age"] = df["Year"] - df["DegreeYear"]

    # Add an interaction between prestige and gender
    df["is_female_x_prestige_decile"] = df["is_female"] * df["prestige_decile"]
    
    return df

def regression_analysis(df, taxonomy="Umbrella", prestige_x_gender_term=False, fixed_field=False):    
    # Run all regressions for Figure 2
    regression_vars = [
                        "is_female",
                        "DegreeYear",
                        "career_age",
                        "prestige_decile",
                        "is_us_degree",
                        ]
        
    if prestige_x_gender_term:
        regression_vars += ["is_female_x_prestige_decile"]

    # Keep track of all odds and models
    df_odds = pd.DataFrame()
    
    ranks_to_run = {"is_attrition": ["Assistant Professor", "Associate Professor", "Professor"],
                    "is_promotion": ["Assistant Professor", "Associate Professor"]}
    
    # Academia-level models
    for event in ["is_attrition", "is_promotion"]:
        for includes_controls in [False, True]:
            for rank_index in ranks_to_run[event]:
                results_row = run_one_regression(df, rank_index, regression_vars, event=event,
                                                 taxonomy_name="Academia", taxonomy_level=taxonomy,
                                                 fixed_field=fixed_field, includes_controls=includes_controls)
                df_odds = pd.concat([df_odds, results_row], ignore_index=True)
        
    # STEM-level models
    for stem_index in ["STEM", "Non-STEM"]:
        for event in ["is_attrition", "is_promotion"]:
            for rank_index in ranks_to_run[event]:
                df_regression = df[(df["STEM"]==stem_index)] 
                results_row = run_one_regression(df_regression, rank_index, regression_vars, event=event,
                                                 taxonomy_name=stem_index, taxonomy_level=taxonomy,
                                                 fixed_field=fixed_field, includes_controls=True)
                df_odds = pd.concat([df_odds, results_row], ignore_index=True)
    
    # Domain-level models
    for umbrella_index in df[taxonomy].drop_duplicates().dropna():
        for event in ["is_attrition", "is_promotion"]:
            for rank_index in ranks_to_run[event]:
                df_regression = df[(df[taxonomy]==umbrella_index)]
                results_row = run_one_regression(df_regression, rank_index, regression_vars, event=event,
                                                 taxonomy_name=umbrella_index, taxonomy_level=taxonomy,
                                                 fixed_field=fixed_field, includes_controls=True)
                df_odds = pd.concat([df_odds, results_row], ignore_index=True)

    return df, df_odds

def compute_decile_bin(row):
    # decile 1 is 0-1
    # decile 10 is 9-10
    prestige_decile = row.prestige_decile
    if prestige_decile > 0:
        binned_decile = np.ceil(prestige_decile)
    elif prestige_decile == 0:
        binned_decile = 1
    return binned_decile

def compute_avg_diffs(avg_probs_df, x_col="binned_decile"):
    """
    After obtaining the average probabilities of leaving across all person-years, 
    compute the difference between men's and women's average probabilities in various subgroups
    """
    avg_probs_diffs = pd.DataFrame(columns=["STEM", "Rank", x_col, "diff"])

    for stem in ["STEM", "Non-STEM"]:
        for rank in ["Assistant Professor", "Associate Professor", "Professor"]:
            for decile in set(avg_probs_df[x_col]):
                sub_df = avg_probs_df[(avg_probs_df.STEM == stem) & 
                                      (avg_probs_df["Rank"] == rank) & 
                                      (avg_probs_df[x_col] == decile)]
                probM = sub_df[sub_df.is_female == 0].prob.item()
                probW = sub_df[sub_df.is_female == 1].prob.item()
                diff = probW / probM

                row = pd.DataFrame([{"STEM": stem, "Rank": rank, x_col: decile, "diff": diff}])
                avg_probs_diffs = pd.concat([avg_probs_diffs, row], ignore_index=True)
                
    return avg_probs_diffs


# PLOTTING
def plot_fig2a(df, df_odds, taxonomy="Umbrella"):
    all_fields_name = "Academia"
    
    plot_order_umbrella=[
        "Academia",
        "STEM",
        "Natural Sciences",
        "Engineering",
        "Mathematics and Computing",
        "Medicine",
        "Non-STEM",
        "Humanities",
        "Social Sciences",
        "Health",
        "Business",
        "Education"]
    
    umbrella_rename_dict = {"Mathematics and Computing":"Math & Computing"}
    
    rank_rename_dict = {
        "Assistant Professor":"Assistant",
        "Associate Professor": "Associate",
        "Professor":"Full",
    }
    space_for_numbers = "                 "
    academia_pos = 13
    
    df_odds["sort"] = df_odds[taxonomy].apply(lambda x: plot_order_umbrella.index(x) if x in plot_order_umbrella else 99)
    df_odds = df_odds.sort_values("sort", ascending=False)
    
    df_odds_attrition_umbrella = df_odds[(df_odds.event == "is_attrition") & (df_odds.includes_controls == True)]
    df_odds_promotion_umbrella = df_odds[(df_odds.event == "is_promotion") & (df_odds.includes_controls == True)]
    
    fig, ax = plt.subplots(1,5,dpi=100, figsize =(8.5,3), sharey=True, sharex=True,
                        gridspec_kw = {"hspace":0.2}) 
    
    # Plot attrition results in the first 3 panels
    for i, rank_index in enumerate(["Assistant Professor","Associate Professor","Professor"]):
        df_odds_to_plot = df_odds_attrition_umbrella[
            (df_odds_attrition_umbrella[taxonomy].isin(plot_order_umbrella)) & 
            (df_odds_attrition_umbrella.Rank==rank_index)] 

        sigs = [False if pval > 0.05 else True for pval in list(df_odds_to_plot['p'])]
        colors = ["grey" if p > 0.05 else "turquoise" if odds > 1 else "black" for odds, 
                  p in zip(df_odds_to_plot["odds"], df_odds_to_plot["p"])] # color by gender
        df_m = {False: ["white"] * len(df_odds_to_plot), True: colors}
        
        for ii in range(len(df_odds_to_plot["odds"])):
            name_to_plot = umbrella_rename_dict.get(df_odds_to_plot[taxonomy].iloc[ii],
                                                    df_odds_to_plot[taxonomy].iloc[ii]) + space_for_numbers
            # First, plot the domains
            if "Academia" not in name_to_plot:
                if ii >= 6:
                    ii_to_plot = ii + 1
                else:
                    ii_to_plot = ii
                
                # Plot the odds ratio and color it grey if not significant, turquoise/grey if women/men more likely 
                ax[i].scatter(df_odds_to_plot["odds"].iloc[ii], ii_to_plot, marker="o", 
                              facecolors=df_m[sigs[ii]][ii], edgecolors=colors[ii], zorder=2)
                
                # Plot the error bars
                ax[i].hlines(ii_to_plot, 
                             df_odds_to_plot["odds_lower_95"].iloc[ii], # xmin
                             df_odds_to_plot["odds_upper_95"].iloc[ii], # xmax
                             color = colors[ii],
                             zorder = 0)

            # Then, plot the academia-level points   
            else:
                ax[i].scatter(df_odds_to_plot["odds"].iloc[ii], academia_pos, marker="o",
                              facecolors=df_m[sigs[ii]][ii], edgecolors=colors[ii], zorder=2)
                
                ax[i].hlines(academia_pos,
                             df_odds_to_plot["odds_lower_95"].iloc[ii], # xmin
                             df_odds_to_plot["odds_upper_95"].iloc[ii], # xmax
                             color = colors[ii],
                             zorder = 0)
                
        ax[i].axvline(x=1, color="darkgrey", zorder=0)
        ax[i].set_title(rank_rename_dict[rank_index], fontsize=11)
        ax[i].spines["top"].set_visible(False)
        ax[i].spines["right"].set_visible(False)

    ax[0].set_title("Assistant", fontsize=11, **{"fontname":"Helvetica"})
    ax[1].set_title("Associate", fontsize=11, **{"fontname":"Helvetica"})
    ax[2].set_title("Full", fontsize=11, **{"fontname":"Helvetica"})
        
    # Plot promotion results in the last 2 panels
    for i, rank_index in enumerate(["Assistant Professor","Associate Professor"], start=3):
        df_odds_to_plot = df_odds_promotion_umbrella[
                    (df_odds_promotion_umbrella[taxonomy].isin(plot_order_umbrella)) & 
                    (df_odds_promotion_umbrella.Rank==rank_index)]
        
        sigs = [False if pval > 0.05 else True for pval in list(df_odds_to_plot["p"])]
        colors = ["grey" if p > 0.05 else "turquoise" if odds > 1 else "black" for odds, 
                  p in zip(df_odds_to_plot["odds"], df_odds_to_plot["p"])] # color by gender
        df_m = {False: ["white"] * len(df_odds_to_plot), True: colors}
        
        for ii in range(len(df_odds_to_plot["odds"])):
            name_to_plot = umbrella_rename_dict.get(df_odds_to_plot[taxonomy].iloc[ii],
                                                    df_odds_to_plot[taxonomy].iloc[ii]) + space_for_numbers
            # First, plot the domains
            if "Academia" not in name_to_plot:
                if ii >= 6: 
                    ii_to_plot = ii+1
                else:
                    ii_to_plot = ii
                    
                ax[i].scatter(df_odds_to_plot["odds"].iloc[ii],ii_to_plot, marker="o",
                              facecolors=df_m[sigs[ii]][ii], edgecolors=colors[ii], zorder=2)
                
                ax[i].hlines(ii_to_plot, 
                                    df_odds_to_plot["odds_lower_95"].iloc[ii], # xmin
                                    df_odds_to_plot["odds_upper_95"].iloc[ii], # xmax
                                    color = colors[ii],
                                    zorder = 0)
            # Then, plot the academia-level point
            else:
                ax[i].scatter(df_odds_to_plot["odds"].iloc[ii],academia_pos, marker="o",
                              facecolors=df_m[sigs[ii]][ii], edgecolors=colors[ii], zorder=2)

                ax[i].hlines(academia_pos,
                             df_odds_to_plot["odds_lower_95"].iloc[ii], # xmin
                             df_odds_to_plot["odds_upper_95"].iloc[ii], # xmax
                             color = colors[ii],
                             zorder = 0)

        ax[i].axvline(x=1, color = "darkgrey", zorder = 0)
        ax[i].spines["top"].set_visible(False)
        ax[i].spines["right"].set_visible(False)
        
    ax[3].set_title("Associate", fontsize=11, **{"fontname":"Helvetica"})
    ax[4].set_title("Full", fontsize=11, **{"fontname":"Helvetica"})
        
    # Legend
    from matplotlib.patches import Patch
    from matplotlib.lines import Line2D

    legend_elements = [Line2D([-0.5,0.5], # Women more likely
                              [0,0],
                              marker="o",
                              markeredgecolor="turquoise",
                              color="turquoise",
                              label="Women more likely",
                              markerfacecolor=None,
                              markersize= 7, 
                              ls='-',
                              linewidth = 2.5),
                       Line2D([-0.5,0.5], # Not significant
                              [0,0],
                              marker="o",
                              markeredgecolor="grey",
                              color="grey",
                              label=r"Not significant (α = 0.05)",
                              markerfacecolor="white",
                              markersize= 7,
                              ls='-',
                              linewidth = 2.5),
                       Line2D([-0.5,0.5], # Men more likely
                              [0,0],
                              marker="o",
                              markeredgecolor="black",
                              color="black",
                              label="Men more likely",
                              markerfacecolor=None,
                              markersize= 7,
                              ls="-",
                              linewidth = 2.5)
                      ]
    
    plt.legend(handles=legend_elements, bbox_to_anchor = (-4.7,1.4), frameon=False, fontsize=11)
    ax[2].set_xlabel("Odds$_{w}$/Odds$_{m}$",size=11)

    # Add in numbers of people per domain
    total_num_people = 0
    ax_label_list = []
    num_people_list = []
    for umbrella in plot_order_umbrella[::-1]:
        if umbrella != "Academia":
            name_to_plot = umbrella_rename_dict.get(umbrella,umbrella)

            if umbrella in ["STEM", "Non-STEM"]:
                count_col = "STEM"
            else:
                count_col = taxonomy

            df_people_used_in_umbrella = df[(df[count_col]==umbrella)&
                                            (~df["SpringRank"].isna())].drop_duplicates(subset=["PersonId"])
            num_people = len(df_people_used_in_umbrella)

            if umbrella not in ["STEM", "Non-STEM"]:
                total_num_people += num_people

            num_spaces = int(40-len(name_to_plot))
            print(f"{name_to_plot:<0}{'{:,}'.format(num_people):>{num_spaces}}")
            ax_label_list+=[name_to_plot]
            num_people_list += ["{:,}".format(num_people)]
                            
    name_to_plot = all_fields_name
    df_people_used_in_umbrella = df[(~df["SpringRank"].isna())].drop_duplicates(subset=["PersonId"])
    num_people = len(df_people_used_in_umbrella)
    ax_label_list+=[name_to_plot]
    num_spaces = int(40-len(name_to_plot))
    print(f"{name_to_plot:<0}{'{:,}'.format(num_people):>{num_spaces}}")

    num_people_list += ["{:,}".format(num_people)]

    trans = blended_transform_factory(x_transform=ax[0].transAxes, y_transform=ax[0].transData)
    for i, num_people in enumerate(num_people_list[:-1]):
        if i < 6: 
            if i == 5: # write "Non-STEM" in bold and the containing domains regular
                ax[0].annotate(num_people, (-0.1,i), ha="right",va="center", xycoords=trans,
                               **{"fontname":"Helvetica","weight":"bold","fontsize":11})
            else:
                ax[0].annotate(num_people, (-0.1,i), ha="right",va="center", xycoords=trans,
                               **{"fontname":"Helvetica","fontsize":11})
        if i >= 6: 
            if i == 10: # write "STEM" in bold and the containing domains regular
                ax[0].annotate(num_people, (-0.1,i+1), ha="right",va="center", xycoords=trans,
                               **{"fontname":"Helvetica","weight":"bold","fontsize":11})
            else:
                ax[0].annotate(num_people, (-0.1,i+1), ha="right",va="center", xycoords=trans,
                               **{"fontname":"Helvetica","fontsize":11})
                
    # write "Academia" in bold
    ax[0].annotate(num_people_list[-1], (-0.1,academia_pos), ha="right", va="center", xycoords=trans,
                   **{"fontname":"Helvetica","weight":"bold","fontsize":11})
        
    # N label
    ax[0].annotate("$N$", (-0.25,academia_pos+1.5), ha="center", va="center", xycoords=trans,
                   **{"fontname":"Helvetica","weight":"bold","fontsize":11})

    trans = blended_transform_factory(x_transform=ax[0].transAxes, y_transform=ax[0].transData)
    for i, num_people in enumerate(ax_label_list[:-1]):
        if i < 6: 
            if i == 5: 
                ax[0].annotate(num_people, (-0.8,i), ha="right", va="center", xycoords=trans,
                               **{"fontname":"Helvetica","weight":"bold","fontsize":11})
            else:
                ax[0].annotate(num_people, (-0.8,i), ha="right", va="center", xycoords=trans,
                               **{"fontname":"Helvetica","fontsize":11})
        if i >= 6:
            if i == 10:
                ax[0].annotate(num_people, (-0.8,i+1), ha="right", va="center", xycoords=trans,
                               **{"fontname":"Helvetica","weight":"bold","fontsize":11})
            else:
                ax[0].annotate(num_people, (-0.8,i+1), ha="right", va="center", xycoords=trans,
                               **{"fontname":"Helvetica","fontsize":11})
       
    ax[0].annotate(ax_label_list[-1], (-0.8,academia_pos), ha="right", va="center", xycoords=trans,
                   **{"fontname":"Helvetica","weight":"bold","fontsize":11})

    con1 = ConnectionPatch(xyA=(-2.3,academia_pos-1), xyB=(1.6,academia_pos-0.7), 
                           coordsA=trans, coordsB="data",
                           axesA=ax[0], axesB=ax[-1], 
                           color="white", zorder = 20, lw = 6)
    
    con2 = ConnectionPatch(xyA=(-2.3,academia_pos-7), xyB=(1.6,academia_pos-6.7), 
                           coordsA=trans, coordsB="data",
                           axesA=ax[0], axesB=ax[-1], 
                           color="white", zorder = 20, lw = 6) 
    
    ax[-1].add_artist(con1)
    ax[-1].add_artist(con2)

    ax[0].set_yticks(ticks=[])
    ax[0].set_xlim(0.5, 1.5)
    ax[0].set_xticks(ticks=[0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.2, 1.3, 1.4, 1.5])
    ax[0].set_xticklabels([0.5, "", "", "", "", 1, "", "", "", "", 1.5])
    
    for i in [3,4]:
        box = ax[i].get_position()
        box.x0 = box.x0 + 0.03
        box.x1 = box.x1 + 0.03
        ax[i].set_position(box)
        
    plt.rcParams["xtick.labelsize"] = 8
    fig.savefig("figures/fig2a.pdf", dpi=300, transparent=True, bbox_inches="tight")
    

def plot_fig2b(avg_probs, avg_probs_diffs):
    fig, ax = plt.subplots(1,3, figsize=(15,4), sharex=True, sharey=False)
    x_col = "binned_decile"
    for i, rank in enumerate(["Assistant Professor", "Associate Professor", "Professor"]):
        avg_to_plot_binned = avg_probs[(avg_probs["Rank"] == rank)]
        men_df = avg_to_plot_binned[avg_to_plot_binned.is_female == 0]
        women_df = avg_to_plot_binned[avg_to_plot_binned.is_female == 1]
        men_stem = men_df[men_df.STEM == "STEM"]
        men_nonstem = men_df[men_df.STEM == "Non-STEM"]
        women_stem = women_df[women_df.STEM == "STEM"]
        women_nonstem = women_df[women_df.STEM == "Non-STEM"]

        sns.lineplot(ax=ax[i], data=men_stem, x="binned_decile", y="prob",color="#4d4d4f", linestyle="solid", linewidth=2)
        sns.lineplot(ax=ax[i], data=men_nonstem, x="binned_decile", y="prob",color="lightgrey", linewidth=2)
        sns.lineplot(ax=ax[i], data=women_stem, x="binned_decile", y="prob",color="teal", linestyle="solid", linewidth=2)
        sns.lineplot(ax=ax[i], data=women_nonstem, x="binned_decile", y="prob",color="paleturquoise", linewidth=2)

        # offset markers
        # 1,3,5, 
        sns.scatterplot(ax=ax[i], data=women_stem[women_stem.binned_decile.isin([1,3,5,7,9,10])], 
                        x="binned_decile", y="prob",color="teal",marker="^", s=120, zorder=10,
                        edgecolor="black", linewidth=0.2)

        # 2,6,10
        sns.scatterplot(ax=ax[i], data=women_nonstem[women_nonstem.binned_decile.isin([1,3,5,7,9,10])],
                        x="binned_decile", y="prob",color="paleturquoise",marker="^", s=120, zorder=10,
                        edgecolor="black", linewidth=0.2)

        # 3,7,
        sns.scatterplot(ax=ax[i], data=men_stem[men_stem.binned_decile.isin([1,2,4,6,8,10])],
                        x="binned_decile", y="prob",color="#4d4d4f",marker="o", s=90, zorder=10,
                        edgecolor="black", linewidth=0.2)

        # 4,8,
        sns.scatterplot(ax=ax[i], data=men_nonstem[men_nonstem.binned_decile.isin([1,2,4,6,8,10])],
                        x="binned_decile", y="prob",color="lightgrey",marker="o", s=90, zorder=10,
                        edgecolor="black", linewidth=0.2)

        ax[i].spines["right"].set_visible(False)
        ax[i].spines["top"].set_visible(False)
        ax[i].legend([],[], frameon=False)

        # INSET-------------------------------------------------------
        left, bottom, width, height = [0.7, 0.8, 0.3, 0.2]
        ax_inset = ax[i].inset_axes([left, bottom, width, height])
        inset_rank_col = "diff"
        inset_x_col = "binned_decile"

        frac=0
        avg_to_plot_inset = avg_probs_diffs[(avg_probs_diffs["Rank"] == rank)]
        lowess_xs_STEM, lowess_ys_STEM = zip(*sm.nonparametric.lowess(
            avg_to_plot_inset[(avg_to_plot_inset.STEM == "STEM")][inset_rank_col],
            avg_to_plot_inset[(avg_to_plot_inset.STEM == "STEM")][inset_x_col],
            frac=frac, 
        ))

        lowess_xs_nonSTEM, lowess_ys_nonSTEM = zip(*sm.nonparametric.lowess(
            avg_to_plot_inset[(avg_to_plot_inset.STEM == "Non-STEM")][inset_rank_col],
            avg_to_plot_inset[(avg_to_plot_inset.STEM == "Non-STEM")][inset_x_col],
            frac=frac, 
        ))

        sns.lineplot(ax=ax_inset, x=lowess_xs_STEM, y=lowess_ys_STEM, linestyle="dashed",color="black")
        sns.lineplot(ax=ax_inset, x=lowess_xs_nonSTEM, y=lowess_ys_nonSTEM, linestyle="solid",color="black")

        ax_inset.axhline(y=1, color="black", linestyle="dotted")
        ax_inset.spines["right"].set_visible(False)
        ax_inset.spines["top"].set_visible(False)
        ax_inset.legend([],[], frameon=False)
        ax_inset.set_ylim([0.5, 1.5])
        ax_inset.set_ylabel(r'$p_{w}$ / $p_{m}$', size=18)
        ax_inset.set_xlabel("")
        ax_inset.set_xticks([1,5,10])
        #-------------------------------------------------------

    for i in [0, 1, 2]:
        ax[i].set_ylim([0,0.09])
        ax[i].set_yticks([0.00, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08])
        ax[i].set_yticklabels(["0.00", "", 0.02, "", 0.04, "", 0.06, "", 0.08], size=12)

    ax[0].set_title("Assistant", size=16, y=1.05)
    ax[1].set_title("Associate", size=16, y=1.05)
    ax[2].set_title("Full", size=16, y=1.05)

    ax[0].axhline(y=0.052612, color="black", linestyle="dotted")
    ax[1].axhline(y=0.033244, color="black", linestyle="dotted")
    ax[2].axhline(y=0.041128, color="black", linestyle="dotted")

    ax[0].set_ylabel("Predicted probability of leaving, $p$", size=16, labelpad=10)
    for i in [0, 1, 2]:
        ax[i].set_xlabel("Prestige decile", size=16, labelpad=10)
        ax[i].set_xticks([i for i in range(1, 11)])
        ax[i].set_xticklabels([i for i in range(1, 11)], size=12)

    ax[1].set_ylabel("")
    ax[2].set_ylabel("")
    
    fig.savefig("figures/fig2b.pdf", dpi=300, transparent=True, bbox_inches="tight")
    

if __name__ == "__main__":
    # Load person-year level employment data
    df = load_data.load_employment()
    
    # Drop person-years missing variables that weren't needed in Fig 1 but are needed in the regression
    df = drop_missing_data(df)
    
    # Make regression features
    df = make_regression_features(df)
    
    # Run regression analyses for:
    # - attrition and promotion, 
    # - with and without controls, 
    # - at academia-level, STEM-level, and domain-level
    # - WITHOUT an interaction between prestige and gender
    # - WITHOUT fixed effects for field
    df, df_odds = regression_analysis(df, taxonomy="Umbrella", prestige_x_gender_term=False, fixed_field=False)
    
    # Remove small domains for the analysis
    df_odds = df_odds[~df_odds.Umbrella.isin(["Journalism, Media, Communication", "Public Administration and Policy"])]
    
    # Plot figure 2A (odds ratios)
    plot_fig2a(df, df_odds, taxonomy="Umbrella")
    
    # Now run the same analyses with the prestige x gender interaction
    df, df_odds = regression_analysis(df, taxonomy="Umbrella", prestige_x_gender_term=True, fixed_field=False)
    
    # Use the models to compute the probability of leaving for each person-year in the dataset
    def compute_prob(row):
        rank = row["Rank"]
        STEM = row["STEM"]

        const = 1
        is_female = row["is_female"]
        degree_year = row["DegreeYear"]
        career_age = row["career_age"]
        decile = row["prestige_decile"]
        is_us_degree = row["is_us_degree"]
        interaction = row["is_female_x_prestige_decile"]
        example = [const, is_female, degree_year, career_age, decile, is_us_degree, interaction]

        model = df_odds[(df_odds.event == "is_attrition") & (df_odds.Umbrella == STEM) & (df_odds.Rank == rank)].model.item()
        prob = model.predict(example).item()
        return prob
    
    df["prob"] = df.apply(compute_prob, axis=1)
    
    # Bin prestige deciles after computing probabilities for visualization
    df["binned_decile"] = df.apply(compute_decile_bin, axis=1)
    
    # Average probabilities across gender, prestige decile, and STEM / Non-STEM
    avg_probs = df.groupby(["STEM", "is_female", "Rank", "binned_decile"])["prob"].mean().reset_index()
    
    # Compute the differences between men's and women's average probs for inset
    avg_probs_diffs = compute_avg_diffs(avg_probs, x_col="binned_decile")
    
    # Plot figure 2B-D
    plot_fig2b(avg_probs, avg_probs_diffs)
    
    
    
    

        



