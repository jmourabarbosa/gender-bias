import pandas as pd
import numpy as np

EMPLOYMENT_DATA = "../data/employment.zip"
SURVEY_DATA = "../data/survey.zip"

def load_employment():
    df = pd.read_csv(EMPLOYMENT_DATA, compression="zip", index_col=0)
    return df

def load_survey():
    df = pd.read_csv(SURVEY_DATA, compression="zip", index_col=0)
    
    # Limit to those with gender identities of Woman, Man, or Non-binary
    df = df[df.gender.isin(["Man", "Woman", "Non-binary"])]
    
    # Limit to those who are in frame
    df = df[df.group != "not_in_frame"]
    
    # Create career age variable:
    # For current faculty, 2021 (survey year) - doctoral degree year, otherwise null
    # For former faculty, the year they left  - doctoral degree year, otherwise null
    conditions = [
        (df['group'] == "current") & (pd.notnull(df['PHD_year'])),
        (df['group'] == "current") & (pd.isnull(df['PHD_year'])),
        (df['group'] != "current") & (pd.notnull(df['year_left']) & (pd.notnull(df['PHD_year']))),
        (df['group'] != "current") & (pd.notnull(df['PHD_year']) & (pd.isnull(df['year_left']))),
        (df['group'] != "current") & (pd.isnull(df['PHD_year']) & (pd.notnull(df['year_left'])))
        ]
    values = [2021 - stress_df["PHD_year"], np.nan, 
              stress_df["year_left"] - stress_df["PHD_year"], np.nan, np.nan]
    df['career_age'] = np.select(conditions, values)
    
    # Add STEM annotation
    STEM_area_taxonomy = {
        # Natural Sciences 
        "Biological Sciences": "STEM",
        "Chemical Sciences": "STEM",
        "Earth Sciences": "STEM",
        "Physical Sciences": "STEM",
        # Medicine & Health
        "Health": "Non-STEM",
        "Medical Sciences": "STEM",
        # Humanities,
        "Humanities": "Non-STEM",
        "Arts": "Non-STEM",
        "History": "Non-STEM",
        "Language, Literature, Culture": "Non-STEM",
        "Linguistics": "Non-STEM",
        "Philosophy": "Non-STEM",
        "Theology and Religion": "Non-STEM",
        # Social Sciences
        "Anthropology": "Non-STEM",
        "Economics": "Non-STEM", 
        "Gender Studies": "Non-STEM",
        "Geography": "Non-STEM",
        "Political Science": "Non-STEM",
        "Psychological Sciences": "Non-STEM", 
        "Sociology": "Non-STEM",
        "Social Sciences": "Non-STEM", 
        # Engineering
        "Engineering": "STEM",
        # Applied Sciences
        "Agriculture": "STEM",
        "Architecture, Design, Planning": "Non-STEM",
        "Business": "Non-STEM",
        # Mathematics & Computing
        "Computational Sciences": "STEM",
        "Mathematical Sciences": "STEM",
        # Education
        "Education": "Non-STEM"
    }
    
    # Create new domain groupings
    area_domain_mapping = {"Agriculture": "Natural Sciences",
                           "Anthropology": "Social Sciences",
                           "Architecture, Design, Planning": "Humanities",
                           "Arts": "Humanities",
                           "Biological Sciences": "Natural Sciences",
                           "Business": "Business",
                           "Chemical Sciences": "Natural Sciences",
                           "Computational Sciences": "Mathematics and Computing",
                           "Earth Sciences": "Natural Sciences",
                           "Economics": "Social Sciences",
                           "Education": "Education",
                           "Engineering": "Engineering",
                           "Gender Studies": "Social Sciences",
                           "Geography": "Social Sciences",
                           "Health": "Health",
                           "History": "Humanities",
                           "Journalism, Media, Communication": "Journalism, Media, Communication",
                           "Language, Literature, Culture": "Humanities",
                           "Linguistics": "Humanities",
                           "Mathematical Sciences": "Mathematics and Computing",
                           "Medical Sciences": "Medicine",
                           "Philosophy": "Humanities",
                           "Physical Sciences": "Natural Sciences",
                           "Political Science": "Social Sciences",
                           "Psychological Sciences": "Social Sciences",
                           "Public Administration and Policy": "Public Administration and Policy",
                           "Sociology": "Social Sciences",
                           "Theology and Religion": "Humanities"
                          }

    df["STEM"] = df["AA_area"].map(STEM_area_taxonomy)
    df["domain"] = df["AA_area"].map(area_domain_mapping)
    
    # Clean up prestige information
    df = df[df["overall_inst_rank"].notna()]
    df = df[df['overall_inst_rank'].str.contains("defaultdict")==False]
    df['overall_inst_rank'] = df["overall_inst_rank"].astype(int)
    df["overall_inst_rank_binary"] = np.where(df["overall_inst_rank"].astype(int) >= 382/2, "low", "high")

    
    
    return df