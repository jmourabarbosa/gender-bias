import numpy as np
import pandas as pd

STEM_area_taxonomy = {
    # Natural Sciences 
    "Biological Sciences": "STEM",
    "Chemical Sciences": "STEM",
    "Earth Sciences": "STEM",
    "Physical Sciences": "STEM",
    # Medicine & Health
    "Health": "Non-STEM",
    "Medical Sciences": "STEM",
    # Humanities,
    "Humanities": "Non-STEM", # domain
    "Arts": "Non-STEM",
    "History": "Non-STEM",
    "Language, Literature, Culture": "Non-STEM",
    "Linguistics": "Non-STEM",
    "Philosophy": "Non-STEM",
    "Theology and Religion": "Non-STEM",
    # Social Sciences
    "Anthropology": "Non-STEM",
    "Economics": "Non-STEM", # STEM?
    "Gender Studies": "Non-STEM",
    "Geography": "Non-STEM",
    "Political Science": "Non-STEM",
    "Psychological Sciences": "Non-STEM", # STEM?
    "Sociology": "Non-STEM",
    "Social Sciences": "Non-STEM", # domain
    # Engineering
    "Engineering": "STEM",
    # Applied Sciences
    "Agriculture": "STEM",
    "Architecture, Design, Planning": "Non-STEM",
    "Business": "Non-STEM",
    # Mathematics & Computing
    "Computational Sciences": "STEM",
    "Mathematical Sciences": "STEM",
    # Education
    "Education": "Non-STEM",
    # Other
    "Journalism, Media, Communication": "Non-STEM",
    "Public Administration and Policy": "Non-STEM"
}

area_domain_mapping = {
    "Agriculture": "Natural Sciences",
    "Anthropology": "Social Sciences",
    "Architecture, Design, Planning": "Humanities",
    "Arts": "Humanities",
    "Biological Sciences": "Natural Sciences",
    "Business": "Business",
    "Chemical Sciences": "Natural Sciences",
    "Computational Sciences": "Mathematics and Computing",
    "Earth Sciences": "Natural Sciences",
    "Economics": "Social Sciences",
    "Education": "Education",
    "Engineering": "Engineering",
    "Gender Studies": "Social Sciences",
    "Geography": "Social Sciences",
    "Health": "Health",
    "History": "Humanities",
    "Journalism, Media, Communication": "Journalism, Media, Communication",
    "Language, Literature, Culture": "Humanities",
    "Linguistics": "Humanities",
    "Mathematical Sciences": "Mathematics and Computing",
    "Medical Sciences": "Medicine",
    "Philosophy": "Humanities",
    "Physical Sciences": "Natural Sciences",
    "Political Science": "Social Sciences",
    "Psychological Sciences": "Social Sciences",
    "Public Administration and Policy": "Public Administration and Policy",
    "Sociology": "Social Sciences",
    "Theology and Religion": "Humanities"
}

def summary_statistics(df):
    depts  = df.DepartmentId.drop_duplicates()
    insts = df.InstitutionId.drop_duplicates()
    people = df.PersonId.drop_duplicates()
    print("D = ", str(len(depts)))  # number of unique departments
    print("I = ", str(len(insts)))  # number of unique institutions
    print("N = ", str(len(people))) # number of unique faculty members
    print("PYs = ", str(len(df)))   # number of person-years

def exceeds_threshold_years(counts, t):
    """
    Function returns list of year-pairs that violate
    the set threshold
    """
    bad_years = []
    years = list(counts.Year)
    for i, yr in enumerate(years[:-1]):
        max_people = max(counts.PersonId[i],counts.PersonId[i+1])
        min_people = min(counts.PersonId[i],counts.PersonId[i+1])
        percent_change = (min_people - max_people) / min_people
        if percent_change > t or percent_change < -t:
            bad_years+= [str(yr)+'-'+str(yr+1)]
    return bad_years

def exceeds_grow_threshold_years(counts, t):
    """
    Function returns list of year-pairs that violate
    the set threshold
    """
    bad_years = []
    years = list(counts.Year)
    for i, yr in enumerate(years[:-1]):
        this_year_count = counts.PersonId[i]
        next_year_count = counts.PersonId[i+1]

        if next_year_count > this_year_count: #ASSERT GROWTH
            max_people = max(counts.PersonId[i],counts.PersonId[i+1])
            min_people = min(counts.PersonId[i],counts.PersonId[i+1])
            percent_change = (min_people - max_people) / min_people
            if percent_change > t or percent_change < -t:
                bad_years+= [str(yr)+"-"+str(yr+1)]
    return bad_years

def exceeds_shrink_threshold_years(counts, t):
    """
    Function returns list of year-pairs that violate
    the set threshold
    """
    bad_years = []
    years = list(counts.Year)
    for i, yr in enumerate(years[:-1]):
        this_year_count = counts.PersonId[i]
        next_year_count = counts.PersonId[i+1]
        
        if next_year_count < this_year_count: #ASSERT SHRINK
            max_people = max(counts.PersonId[i],counts.PersonId[i+1])
            min_people = min(counts.PersonId[i],counts.PersonId[i+1])
            percent_change = (min_people - max_people) / min_people
            if percent_change > t or percent_change < -t:
                bad_years+= [str(yr)+'-'+str(yr+1)]
    return bad_years

def missing_years(list_of_years):
    """
    Returns the year ranges to discount 
    due to a department's missing years
    """
    min_year = min(list_of_years)
    max_year = max(list_of_years)

    years_to_check = list(range(min_year, max_year+1))
    bad_years = []
    
    for year in years_to_check:
        if year not in list_of_years:
            bad_years += [str(year-1)+'-'+str(year)]
            bad_years += [str(year)+'-'+str(year+1)]
    return bad_years

def exclude_last_year(list_of_years):
    """
    Flag the last year that a department shows up
    in the dataset to avoid mass false attritions
    """
    max_year = max(list_of_years)
    return [str(max_year)+'-'+str(max_year+1)]

def get_bad_years(counts, settings):
    """
    Combines missing_years, exceeds_threshold_years, and exclude_last_year functions
    """
    counts = counts.reset_index()
    counts=counts.rename(columns = {counts.columns[2]:'PersonId'})
    
    exceeds_threshold = []
    if settings["grow"]:
        exceeds_threshold += exceeds_grow_threshold_years(counts, settings["grow_shrink_threshold"])
    if settings["shrink"]:
        exceeds_threshold += exceeds_shrink_threshold_years(counts, settings["grow_shrink_threshold"])

    list_of_years = list(counts.Year)
    
    missing_dept = []
    if settings["tag_depts_that_disappear"]:
        missing_dept += missing_years(list_of_years)

    last_year = exclude_last_year(list_of_years)
          
    return list(set(exceeds_threshold + missing_dept + last_year))

def clean_departments(df, settings):
    # Tag years where departments are missing, and years where departments grow or shrink beyond the threshold 
    dept_yearly_counts = df.groupby("DepartmentId").apply(lambda x: x.groupby("Year")["PersonId"].nunique())
    dept_exclude_years = dept_yearly_counts.groupby("DepartmentId").apply(lambda x: get_bad_years(x,settings))
    exclude_years_dict = dict(dept_exclude_years)
    df["exclude_years"] = df["DepartmentId"].apply(lambda x: [] if pd.isna(x) else exclude_years_dict[x])

    print("Tagging department year ranges that grow/shrink by 50% in any year, and years that are missing:")
    summary_statistics(df)
    
    return df

def get_highest_rank(ranks):
    if "Professor" in ranks:
        return "Professor"
    if "Associate Professor" in ranks:
        return "Associate Professor"
    if "Assistant Professor" in ranks:
        return "Assistant Professor"
    raise(f"error! non-rank input: {ranks}")
    
    
def get_promotion_years(yearly_rank):
    """
    Get the years each professor was promoted
    """
    yearly_rank = yearly_rank.reset_index()
    yearly_rank=yearly_rank.rename(columns = {yearly_rank.columns[2]:"ranks"})
    promotion_years = []
    years = list(yearly_rank.Year)

    promoted_to_associate = False
    promoted_to_full = False

    for i, yr in enumerate(years[:-1]):
        this_year_rank = get_highest_rank(yearly_rank.ranks[i])
        next_year_rank = get_highest_rank(yearly_rank.ranks[i+1])
        
        if (this_year_rank == "Assistant Professor") & (next_year_rank == "Associate Professor"):
            if promoted_to_associate == False:
                # Promoted to Associate
                promoted_to_associate = True
                promotion_years +=[yr]
        
        if (this_year_rank == "Associate Professor") & (next_year_rank == "Professor"):
            if promoted_to_full == False:
                # Promoted to Full
                promoted_to_full = True
                promotion_years +=[yr]
                
    return promotion_years

def make_person_records(PersonId, start_year, promotion_years, end_year,):
    """
    Make person records, a format where for each person, we can see the years they were in the dataset
    """
    rows = []
    for year in range(start_year, end_year+1):
        event = "no_promotion"
        if year in promotion_years:
            event = "promotion"
        if (year == end_year) and (year != 2020):
            event = "attrition"
        row = {
            "PersonId":PersonId,
            "Year":year,
            "Year_y":year+1,
            "event":event,
        }
        if year != 2020:
            rows += [row]     
    return rows


if __name__ == "__main__":
    # load in unprocessed data
    df = pd.read_csv("../../data/raw_employment.zip")
    summary_statistics(df) # Start with 305K faculty 

    # add gender-name classifications
    df_gender = pd.read_csv("../../data/gender_name_classifications.zip")
    df_gender = df_gender[["PersonName","Label"]]
    df_gender = df_gender.drop_duplicates()
    df = df.merge(df_gender, on="PersonName", how="left")
    df = df.drop(columns=["Gender"])
    df = df.rename(columns = {"Label":"Gender"})

    # Preprocessing settings
    settings = {'grow':True,                        # remove departments that grow by threshold in a given year
                'shrink':True,                      # remove departments that shrink by threshold in a given year
                'grow_shrink_threshold':0.5,        # grow/shrink threshold for removal (0.5 = 50%)
                'tag_depts_that_disappear':True,    # remove departments that disappear
                'tag_depts_below_given_size':True,  # remove departments that are smaller than a threshold
                'dept_size_threshold':3             # size threshold for removal (number of people)
               }
    
    # tag departments given settings
    cleaned_depts_df = clean_departments(df, settings)

    print("Before dropping secondary appointments, get department sizes for later")
    # create dept_count column, which reports the number of unique people in each department across all years
    dept_counts = cleaned_depts_df.groupby("DepartmentId")["PersonId"].nunique()
    cleaned_depts_df["dept_count"] = cleaned_depts_df["DepartmentId"].map(dept_counts)

    print("Dropping secondary appointments")
    cleaned_depts_df = cleaned_depts_df[cleaned_depts_df["PrimaryAppointment"]]
    summary_statistics(cleaned_depts_df)

    print("Fill in missing department info for imputed people")
    # make list of people who are missing information
    people_missing_info = cleaned_depts_df[cleaned_depts_df["DepartmentId"].isna()]["PersonId"].drop_duplicates()

    # forward fill their information and collect into records
    filled_in_people_years = []
    for pid in people_missing_info:
        df_person = cleaned_depts_df[cleaned_depts_df["PersonId"]==pid]
        df_person_filled = df_person.sort_values("Year").fillna(method="ffill")
        filled_in_people_years += df_person_filled.to_dict("records")
        
    # drop people who were missing information 
    cleaned_depts_df = cleaned_depts_df[~cleaned_depts_df["PersonId"].isin(people_missing_info)]

    # Now, append the people who were missing information
    df_people_missing_info = pd.DataFrame(filled_in_people_years)
    cleaned_depts_df = pd.concat([cleaned_depts_df, df_people_missing_info], ignore_index=True)
    summary_statistics(cleaned_depts_df)

    print(f"Tag departments with less than {settings['dept_size_threshold']} people to be excluded")
    # populate all_years with all years in the dataset
    all_years = []
    for year in range(2011, 2020):
        all_years += [str(year)+"-"+str(year+1)]

    # get number of departments that we're dropping for being too small
    num_to_exclude_all_years = len(cleaned_depts_df.loc[
        cleaned_depts_df["dept_count"] < settings["dept_size_threshold"],"exclude_years"])
    
    if settings["tag_depts_below_given_size"]:
        # tag small departments to be excluded in all years
        cleaned_depts_df.loc[cleaned_depts_df["dept_count"] < settings["dept_size_threshold"], "exclude_years"] = [[all_years]]*num_to_exclude_all_years
        
        cleaned_depts_df.loc[cleaned_depts_df["dept_count"] < settings["dept_size_threshold"], "exclude_years"] = cleaned_depts_df.loc[cleaned_depts_df["dept_count"] < settings["dept_size_threshold"], "exclude_years"].apply(lambda x: x[0])

    summary_statistics(cleaned_depts_df)

    # Preprocessing steps 
    df = cleaned_depts_df

    print("Fill in missing fields from above in the taxonomy")
    df["Area"] = df["Area"].fillna(df["Umbrella"]) # Filling in missing fields from above in the taxonomy
    df["Field"] = df["Field"].fillna(df["Area"]) # Filling in missing fields from above in the taxonomy
 
    print("Remove people without male/female gender labels")
    df = df[df['Gender'].isin(["Male", "Female"])]
    summary_statistics(df)

    # Get the years people were promoted in
    group = df.groupby(by = ["PersonId", "Year"])["Rank"].apply(list).groupby("PersonId")
    promotion_years = group.apply(get_promotion_years)

    # Get the first and last year each person was in the dataset
    first_year_in_aa = df.groupby("PersonId")["Year"].min()
    last_year_in_aa = df.groupby("PersonId")["Year"].max()

    # Make person records 
    person_years = df["PersonId"].drop_duplicates().apply(
        lambda pid: make_person_records(pid, first_year_in_aa[pid], promotion_years[pid], last_year_in_aa[pid]))
    person_years_list = person_years.to_list()
    person_years_flat = [item for sublist in person_years_list for item in sublist]
    df_person_years = pd.DataFrame(person_years_flat)
    df_person_years["event"].value_counts()

    # Merge in person information. Outer merge will preserve multiple appointments.
    df_merge = df_person_years.merge(df, how="outer", on=["Year","PersonId"])

    # Outer merge will loop 2020s back in. Drop them here. 
    df_merge = df_merge[df_merge["Year"] != 2020]

    to_drop = df_merge[df_merge["exclude_years"].isna()].index
    print(f"Dropping {len(to_drop)} person-years which do not have primary appointments for a \
          span of years due to changing to multiple departments at once") 
    
    df_merge = df_merge.drop(to_drop)
    summary_statistics(df_merge)

    print("Drop person-years that are set to be excluded")
    df_merge["exclude_year_start"] = df_merge["exclude_years"].apply(lambda x: [int(date.split("-")[0]) for date in x])
    to_exclude = df_merge.apply(lambda row: row["Year"] in row["exclude_year_start"], axis=1)
    df_merge = df_merge[~to_exclude]

    summary_statistics(df_merge)

    # Annotating with additional data
    df = df_merge
    
    # Add STEM / Non-STEM classification
    df["STEM"] = df["Area"].map(STEM_area_taxonomy)
    df["Umbrella"] = df["Area"].map(area_domain_mapping)
    
    df.event = df.event.replace({"no_promotion":"retention"})
    df = df.reset_index(drop=True)
    
    # Import and merge ranks
    df_aa_ranks = pd.read_csv("../../data/institution_ranks.zip")
    taxonomy_to_use = "Area"
    df_aa_ranks_umbrella = df_aa_ranks[df_aa_ranks["TaxonomyLevel"]==taxonomy_to_use]

    # Load two types of ranks; Spring Rank is an ordered rank, whereas ZeroToOne has been transformed to be between 0 and 1 
    df["SpringRank"] = df.merge(df_aa_ranks_umbrella, 
                        how="left", 
                        left_on=["InstitutionId",taxonomy_to_use],
                        right_on=["InstitutionId","TaxonomyValue"],
                        suffixes=("","_prestige"))["Rank_prestige"]

    df["ZeroToOneRank"] = df.merge(df_aa_ranks_umbrella, 
                        how="left", 
                        left_on=["InstitutionId",taxonomy_to_use],
                        right_on=["InstitutionId","TaxonomyValue"],
                        suffixes=("","_prestige"))["ZeroToOneRank"]
    
    # Import and merge degree institution country
    df_degree_country = pd.read_csv("../../data/institution-countries.zip")
    df_degree_country = df_degree_country[["DegreeInstitutionId","CountryName"]]
    df = df.merge(df_degree_country, on="DegreeInstitutionId")
    
    # Only include people with career age <= 40
    df["career_age"] = df["Year"] - df["DegreeYear"]
    df = df[df.career_age <= 40]
    print("Dropping people with career age > 40")
    summary_statistics(df)
    
    df.to_csv("../data/employment.zip")