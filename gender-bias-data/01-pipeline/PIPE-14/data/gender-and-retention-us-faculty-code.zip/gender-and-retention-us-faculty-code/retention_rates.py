import random
import collections

import numpy as np
import pandas as pd
pd.options.mode.chained_assignment = None  # default='warn'

import statsmodels.api as sm

import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.colors import ListedColormap, BoundaryNorm
import seaborn as sns

from scripts import load_data

custom_params = {"axes.spines.right": False, 
                 "axes.spines.top": False,
                 "figure.figsize":(12,8),
                 'xtick.bottom': True,
                 'ytick.left': True}

sns.set_theme(style="white", rc=custom_params)
plt.rcParams.update({'font.family':'Helvetica'})


def compute_annual_risk(df, 
                        groupby_cols=["career_age", "Gender"], 
                        taxonomy_col="Academia", 
                        compute_col="attrition"):
    """
    Compute the annual risk of the event in compute_col ("attrition", "promotion_asst" or "promotion_assoc") where:
        Annual risk = # of actual events / # of possible events
        
    Duplicates are used during bootstrapping (sampling with replacement)
    """
    df = df.copy()
    
    groupby_cols = groupby_cols + [taxonomy_col]
    
    # Compute the total number of people of that career age who could have left (or been promoted)
    df["possible_people"] = df.groupby(groupby_cols)["PersonId"].transform("nunique")
    df["possible_duplicates"] = df.groupby(groupby_cols)["num_dups"].transform("sum")
    df["possible_events"] = df["possible_people"] + df["possible_duplicates"]
    
    df = df[df[compute_col]].drop(columns=[compute_col])

    # Compute the total number of people of that career age who did leave (or were promoted)
    df["people"] = df.groupby(groupby_cols)["PersonId"].transform("nunique")
    df["duplicates"] = df.groupby(groupby_cols)["num_dups"].transform("sum")
    df["events"] = df["people"] + df["duplicates"]

    df = df[groupby_cols + ["possible_events", "events"]].drop_duplicates()
    df["annual_risk"] = df["events"] / df["possible_events"]
    return df

def compute_cumulative_risk(df, col="annual_risk"):   
    """
    Uses annual risk to calculate the cumulative risk over a career
    """
    cumulative_risk = {}
    for yr in range(1,41):
        p = df[df.career_age == yr][col].item() # probability of event in that year
        if yr == 1:
            cumulative_risk[yr] = p
        else:
            prior_yr = cumulative_risk[yr-1]
            total_risk = (p * (1 - prior_yr)) + prior_yr
            cumulative_risk[yr] = total_risk
    return cumulative_risk

def cumulative_risk_by_domain(df):
    """
    Calculate cumulative risk separately for each domain (umbrella)
    """
    combined_domain_data = []
    for domain in ["Applied Sciences", "Education", "Engineering", "Mathematics and Computing", "Humanities", 
                   "Medicine and Health", "Natural Sciences", "Social Sciences"]:
        domain_df = df[df.Umbrella == domain]
        men_df = domain_df[domain_df.Gender == "Male"]
        men_cumulative_risk = compute_cumulative_risk(men_df)
        men_df["cumulative_risk"] = men_df["career_age"].map(men_cumulative_risk)

        women_df = domain_df[domain_df.Gender == "Female"]
        women_cumulative_risk = compute_cumulative_risk(women_df)
        women_df["cumulative_risk"] = women_df["career_age"].map(women_cumulative_risk)

        combined_df = pd.concat([men_df, women_df], ignore_index=True)
        combined_domain_data.append(combined_df)
        
    combined_domain_df = pd.concat(combined_domain_data)
    return combined_domain_df

def sample(df, people):
    """
    Sample with replacement a random set of faculty careers, implemented by assigning those selected a number of duplicates
    All records of each person sampled are included in sample_df 
    """
    sample = [random.choice(people) for _ in people]
    sample_df = df[df.PersonId.isin(sample)]
    frequencies = dict(collections.Counter(sample))
    sample_df["num_dups"] = sample_df["PersonId"].map(frequencies) - 1
    return sample_df

def get_bounds(iterations, gender, col="annual_risk", yrs=40, pct_min=0, pct_max=100):
    """
    For each career year, get the bootstrapped rates that correspond to the given 
    minimum and maxiumum percentiles (pct_min and pct_max).
    """
    r_max_list = []
    r_min_list = []
    
    for yr in range(1, yrs+1):
        iteration_list = []
        for i in iterations:
            i_df = iterations[i]
            yr_df = i_df[(i_df.career_age == yr) & (i_df.Gender == gender)][col]
            
            if len(yr_df) > 0:
                r = i_df[(i_df.career_age == yr) & (i_df.Gender == gender)][col].item()
            else:
                r = 0

            iteration_list.append(r)
        
        # get min
        r_min_list.append(np.percentile(iteration_list, pct_min))
        
        # get max
        r_max_list.append(np.percentile(iteration_list, pct_max))
        
    return r_max_list, r_min_list

def bootstrapping_iteration(df, people, taxonomy_col="Academia", compute_col="attrition"):
    """
    Run one bootstrap iteration, by taking a sample with replacement and computing the annual risk on that sample.
    """
    sample_df = sample(df, people)
    groupby_cols = ["career_age", taxonomy_col, "Gender"]
    i_df = compute_annual_risk(sample_df, groupby_cols=groupby_cols, taxonomy_col=taxonomy_col, compute_col=compute_col)
    return i_df

def compute_deltas(domain_df, empirical_M, empirical_W):
    """
    Compute cumulative risk deltas (women's risk - men's risk) at academia and domain levels for Fig 1A inset.
    """
    all_domain_deltas = []
    for domain in set(domain_df.Umbrella):
        domain_deltas = []
        for yr in range(1,41):
            yr_df = domain_df[(domain_df.Umbrella == domain) & (domain_df.career_age == yr)]
            women_risk = yr_df[yr_df.Gender == "Female"].cumulative_risk.item()
            men_risk = yr_df[yr_df.Gender == "Male"].cumulative_risk.item()
            delta = women_risk - men_risk
            domain_deltas.append(delta)
        all_domain_deltas.append(domain_deltas)
    
    # Also calculate academia-level cumulative risk deltas to compare to domain-level deltas
    men_cumulative_risk = compute_cumulative_risk(empirical_M)
    women_cumulative_risk = compute_cumulative_risk(empirical_W)
    empirical_M["cumulative_risk"] = empirical_M["career_age"].map(men_cumulative_risk)
    empirical_W["cumulative_risk"] = empirical_W["career_age"].map(women_cumulative_risk)
    combined_df = pd.concat([empirical_M, empirical_W], ignore_index=True)

    academia_deltas = []
    for yr in range(1,41):
        yr_df = combined_df[combined_df.career_age == yr]
        women_risk = yr_df[yr_df.Gender == "Female"].cumulative_risk.item()
        men_risk = yr_df[yr_df.Gender == "Male"].cumulative_risk.item()
        delta = women_risk - men_risk
        academia_deltas.append(delta)
    
    return all_domain_deltas, academia_deltas


# PLOTTING
def plot_fig1a(empirical_W, empirical_M, 
               r_max_list_W, r_max_list_M, 
               r_min_list_W, r_min_list_M, 
               umbrella_deltas, academia_deltas,
               y_col = "annual_risk", frac = 0.15):
    fig, ax = plt.subplots(figsize=(8,6))
    left, bottom, width, height = [0.25, 0.58, 0.3, 0.3]
    ax_inset = fig.add_axes([left, bottom, width, height])

    yrs = [y for y in range(1,41)]
    
    # Smooth curves using frac
    lowess_xs_mid_W, lowess_ys_mid_W = zip(*sm.nonparametric.lowess(empirical_W[y_col], yrs, frac=frac))
    lowess_xs_max_W, lowess_ys_max_W = zip(*sm.nonparametric.lowess(r_max_list_W, yrs, frac=frac))
    lowess_xs_min_W, lowess_ys_min_W = zip(*sm.nonparametric.lowess(r_min_list_W, yrs, frac=frac))
    lowess_xs_mid_M, lowess_ys_mid_M = zip(*sm.nonparametric.lowess(empirical_M[y_col], yrs, frac=frac))
    lowess_xs_max_M, lowess_ys_max_M = zip(*sm.nonparametric.lowess(r_max_list_M, yrs, frac=frac))
    lowess_xs_min_M, lowess_ys_min_M = zip(*sm.nonparametric.lowess(r_min_list_M, yrs, frac=frac))

    # PLOT 
    # Women
    ax.plot(lowess_xs_mid_W, lowess_ys_mid_W, color="turquoise", linewidth=2, label="Women")
    ax.plot(lowess_xs_max_W, lowess_ys_max_W, color="turquoise", linewidth=0.25)
    ax.plot(lowess_xs_min_W, lowess_ys_min_W, color="turquoise", linewidth=0.25)
    ax.fill_between(yrs, lowess_ys_max_W, lowess_ys_mid_W, color="turquoise", alpha=0.3)
    ax.fill_between(yrs, lowess_ys_mid_W, lowess_ys_min_W, color="turquoise", alpha=0.3)
    ax.scatter(yrs, empirical_W[y_col], color="turquoise", s=10)

    # Men
    ax.plot(lowess_xs_mid_M, lowess_ys_mid_M, color="grey", linewidth=2, label="Men")
    ax.plot(lowess_xs_max_M, lowess_ys_max_M, color="grey", linewidth=0.25)
    ax.plot(lowess_xs_min_M, lowess_ys_min_M, color="grey", linewidth=0.25)
    ax.fill_between(yrs, lowess_ys_max_M, lowess_ys_mid_M, color="grey", alpha=0.3)
    ax.fill_between(yrs, lowess_ys_mid_M, lowess_ys_min_M, color="grey", alpha=0.3)    
    ax.scatter(yrs, empirical_M[y_col], color="grey", s=10)

    # INSET---------------------------------------------------------
    for i in range(len(umbrella_deltas)):
        import numpy.ma as ma
        # generate the masked array
        x = np.array(yrs)
        y = np.array(umbrella_deltas[i][:40])
        mask_women = ma.masked_less_equal(y, 0)
        mask_men = ma.masked_greater(y, 0)
        ax_inset.plot(x, mask_men, "grey", linewidth=0.2)
        ax_inset.plot(x, mask_women, "turquoise", linewidth=0.2)

    ax_inset.plot(np.array(yrs), np.array(academia_deltas)[:40], color="turquoise", linewidth=3)
    ax_inset.axhline(0, color="k", ls="--")
    ax_inset.set_ylim([-0.15, 0.15])
    ax_inset.set_ylabel(r"$\Delta$ Cumulative risk ($W - M$)", fontsize=12, labelpad=5)
    ax_inset.set_xlabel(r"Career age, $t$ (years since PhD)", fontsize=12, labelpad=10)
    ax_inset.set_xticks([1, 5, 10, 15, 20, 25, 30, 35, 40])
    ax_inset.set_xticklabels([1, 5, 10, 15, 20, 25, 30, 35, 40], fontsize=12)
    ax_inset.set_yticks([-0.1, 0.0, 0.1])
    ax_inset.set_yticklabels([-0.1, 0.0, 0.1], fontsize=12)
    # ---------------------------------------------------------------

    ax.set_yticks([0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.10, 0.11, 0.12, 0.13, 0.14])
    ax.set_yticklabels(["0%", "", "2%", "", "4%", "", "6%", "", "8%", "", "10%", "", "12%", "", "14%"], fontsize=16)
    ax.set_xticks([i+1 for i in range(40)])
    ax.set_xticklabels([1, "", "", "", 
                        5, "", "", "", "",
                        10, "", "", "", "",
                        15, "", "", "", "",
                        20, "", "", "", "",
                        25, "", "", "", "",
                        30, "", "", "", "",
                        35, "", "", "", "",40], fontsize=16)
    ax.set_ylim(0, 0.14)
    ax.set_ylabel(r"  Annual attrition risk, $r$", fontsize=20, labelpad=10)
    ax.set_xlabel(r"Career age, $t$ (years since PhD)", fontsize=20, labelpad=10)

    plt.tight_layout()
    fig.savefig("figures/fig1a.pdf", dpi=300)

def threshold_plot(ax, x, y, threshv, color, overcolor):
    """
    Helper function to plot points above a threshold in a different color
    - x, y : array. The x and y values
    - threshv : float. Plot using overcolor above this value
    - color : color. The color to use for the lower values
    - overcolor: color.The color to use for values over threshv
    """
    # Create a colormap and a norm to color
    cmap = ListedColormap([color, overcolor])
    norm = BoundaryNorm([np.min(y), threshv, np.max(y)], cmap.N)

    # Create a set of line segments so that we can color them individually
    # This creates the points as a N x 1 x 2 array so that we can stack points
    # together easily to get the segments. The segments array for line collection
    # needs to be numlines x points per line x 2 (x and y)
    points = np.array([x, y]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)

    # Create the line collection object, setting the colormapping parameters.
    # Have to set the actual values used for colormapping separately.
    lc = LineCollection(segments, cmap=cmap, norm=norm)
    lc.set_array(y)

    ax.add_collection(lc)
    ax.set_xlim(np.min(x), np.max(x))
    ax.set_ylim(np.min(y)*1.1, np.max(y)*1.1)
    return lc

def plot_fig1b(empirical_W_p1, empirical_M_p1,
               empirical_W_p2, empirical_M_p2,
               p1_max_list_W, p1_max_list_M,
               p1_min_list_W, p1_min_list_M,
               p2_max_list_W, p2_max_list_M,
               p2_min_list_W, p2_min_list_M,
               y_col="annual_risk", frac=0.12, line_alpha=0.25):
    fig, ax = plt.subplots(figsize=(8,6))
    yrs = [y for y in range(1,41)]

    empirical_W_p1 = empirical_W_p1.sort_values("career_age")
    empirical_M_p1 = empirical_M_p1.sort_values("career_age")
    empirical_W_p2 = empirical_W_p2.sort_values("career_age")
    empirical_M_p2 = empirical_M_p2.sort_values("career_age")
    
    # Smooth curves using frac
    # Women
    lowess_xs_mid_W_p1, lowess_ys_mid_W_p1 = zip(*sm.nonparametric.lowess(empirical_W_p1[y_col], yrs, frac=frac))
    lowess_xs_max_W_p1, lowess_ys_max_W_p1 = zip(*sm.nonparametric.lowess(p1_max_list_W, yrs, frac=frac))
    lowess_xs_min_W_p1, lowess_ys_min_W_p1 = zip(*sm.nonparametric.lowess(p1_min_list_W, yrs, frac=frac))
    lowess_xs_mid_W_p2, lowess_ys_mid_W_p2 = zip(*sm.nonparametric.lowess(empirical_W_p2[y_col], yrs, frac=frac))
    lowess_xs_max_W_p2, lowess_ys_max_W_p2 = zip(*sm.nonparametric.lowess(p2_max_list_W, yrs, frac=frac))
    lowess_xs_min_W_p2, lowess_ys_min_W_p2 = zip(*sm.nonparametric.lowess(p2_min_list_W, yrs, frac=frac))

    # Men
    lowess_xs_mid_M_p1, lowess_ys_mid_M_p1 = zip(*sm.nonparametric.lowess(empirical_M_p1[y_col], yrs, frac=frac))
    lowess_xs_max_M_p1, lowess_ys_max_M_p1 = zip(*sm.nonparametric.lowess(p1_max_list_M, yrs, frac=frac))
    lowess_xs_min_M_p1, lowess_ys_min_M_p1 = zip(*sm.nonparametric.lowess(p1_min_list_M, yrs, frac=frac))
    lowess_xs_mid_M_p2, lowess_ys_mid_M_p2 = zip(*sm.nonparametric.lowess(empirical_M_p2[y_col], yrs, frac=frac))
    lowess_xs_max_M_p2, lowess_ys_max_M_p2 = zip(*sm.nonparametric.lowess(p2_max_list_M, yrs, frac=frac))
    lowess_xs_min_M_p2, lowess_ys_min_M_p2 = zip(*sm.nonparametric.lowess(p2_min_list_M, yrs, frac=frac))

    # PLOT 
    # Women
    ax.plot(lowess_xs_mid_W_p1, lowess_ys_mid_W_p1, color="turquoise", linewidth=2, label="Women")
    ax.plot(lowess_xs_max_W_p1, lowess_ys_max_W_p1, color="turquoise", linewidth=0.25)
    ax.plot(lowess_xs_min_W_p1, lowess_ys_min_W_p1, color="turquoise", linewidth=0.25)
    ax.plot(lowess_xs_mid_W_p2, lowess_ys_mid_W_p2, color="turquoise", linewidth=2, label="Women")
    ax.plot(lowess_xs_max_W_p2, lowess_ys_max_W_p2, color="turquoise", linewidth=0.25)
    ax.plot(lowess_xs_min_W_p2, lowess_ys_min_W_p2, color="turquoise", linewidth=0.25)
    ax.fill_between(yrs, lowess_ys_max_W_p1, lowess_ys_mid_W_p1, color="turquoise", alpha=0.3)
    ax.fill_between(yrs, lowess_ys_mid_W_p1, lowess_ys_min_W_p1, color="turquoise", alpha=0.3)
    ax.fill_between(yrs, lowess_ys_max_W_p2, lowess_ys_mid_W_p2, color="turquoise", alpha=0.3)
    ax.fill_between(yrs, lowess_ys_mid_W_p2, lowess_ys_min_W_p2, color="turquoise", alpha=0.3)
    ax.scatter(yrs, empirical_W_p1[y_col], color="turquoise", s=10)
    ax.scatter(yrs, empirical_W_p2[y_col], color="turquoise", s=10)

    # Men
    ax.plot(lowess_xs_mid_M_p1, lowess_ys_mid_M_p1, color="grey", linewidth=2, label="Men")
    ax.plot(lowess_xs_max_M_p1, lowess_ys_max_M_p1, color="grey", linewidth=0.25)
    ax.plot(lowess_xs_min_M_p1, lowess_ys_min_M_p1, color="grey", linewidth=0.25)
    ax.plot(lowess_xs_mid_M_p2, lowess_ys_mid_M_p2, color="grey", linewidth=2, label="Men")
    ax.plot(lowess_xs_max_M_p2, lowess_ys_max_M_p2, color="grey", linewidth=0.25)
    ax.plot(lowess_xs_min_M_p2, lowess_ys_min_M_p2, color="grey", linewidth=0.25)
    ax.fill_between(yrs, lowess_ys_max_M_p1, lowess_ys_mid_M_p1, color="grey", alpha=0.3)
    ax.fill_between(yrs, lowess_ys_mid_M_p1, lowess_ys_min_M_p1, color="grey", alpha=0.3)
    ax.fill_between(yrs, lowess_ys_max_M_p2, lowess_ys_mid_M_p2, color="grey", alpha=0.3)
    ax.fill_between(yrs, lowess_ys_mid_M_p2, lowess_ys_min_M_p2, color="grey", alpha=0.3)
    ax.scatter(yrs, empirical_M_p1[y_col], color="grey", s=10)
    ax.scatter(yrs, empirical_M_p2[y_col], color="grey", s=10)

    plt.ylabel(r"  Annual promotion rate, $p$", fontsize=20, labelpad=10)
    plt.xlabel(r"Career age, $t$ (years since PhD)", fontsize=20, labelpad=10)
    plt.yticks([0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.10, 0.11, 0.12, 0.13, 0.14])
    ax.set_yticklabels(["0%", "", "2%", "", "4%", "", "6%", "", "8%", "", "10%", "", "12%", "", "14%"], fontsize=16)
    ax.set_xticks([i+1 for i in range(40)])
    ax.set_xticklabels([1, "", "", "", 
                        5, "", "", "", "",
                        10, "", "", "", "",
                        15, "", "", "", "",
                        20, "", "", "", "",
                        25, "", "", "", "",
                        30, "", "", "", "",
                        35, "", "", "", "",40], fontsize=16)

    fig.savefig("figures/fig1b.pdf", dpi=300)

    
if __name__ == "__main__":
    # Load person-year level employment data
    df = load_data.load_employment()
    df["attrition"] = df.event == "attrition"
    df["career_age"] = df["Year"] - df["DegreeYear"]
    df = df[(df.career_age <= 40) & (df.career_age > 0)]
    df["num_dups"] = [0] * len(df) # each record starts with 0 duplicates; duplicates added later on for bootstrapping 
    
    people = list(set(df.PersonId))
    print(df.PersonId.nunique())
    
    # Calculate the empirical academia-wide retention rates
    empirical_df = compute_annual_risk(df, taxonomy_col = "Academia", compute_col = "attrition")
    empirical_W = empirical_df[empirical_df.Gender == "Female"]
    empirical_M = empirical_df[empirical_df.Gender == "Male"]
    
    # Estimate projections given empirical retention rates
    print("Starting with a 50-50 cohort hired at gender parity, assuming rates are steady over time, what will \
          the gender ratio be after x years?")
    n_w = 50
    n_m = 50
    for yr in range(1,40):
        print(yr)
        risk_w = empirical_W[(empirical_W.career_age == yr)].annual_risk.item()
        risk_m = empirical_M[(empirical_M.career_age == yr)].annual_risk.item()
        
        n_w *= (1 - risk_w)
        n_m *= (1 - risk_m)

        gender_ratio = n_w / (n_w + n_m)
        print(n_w)
        print(n_m)
        print(gender_ratio)
    
    # Perform bootstrapping over faculty careers to obtain error bounds
    num_iters = 1000
    fig1a_iterations = {}
    
    for i in range(num_iters):
        i_df = bootstrapping_iteration(df, people, taxonomy_col="Academia", compute_col="attrition")
        fig1a_iterations[i] = i_df
    
    r_max_list_W, r_min_list_W = get_bounds(fig1a_iterations, gender="Female", pct_min=2.5, pct_max=97.5)
    r_max_list_M, r_min_list_M = get_bounds(fig1a_iterations, gender="Male", pct_min=2.5, pct_max=97.5)
    
    # Calculate domain-level retention rates
    # For ease of visualization, calculate deltas between cumulative risks (women's risk - men's risk) 
    #     rather than raw attrition rates per domain and gender
    domain_df = compute_annual_risk(df, taxonomy_col="Umbrella", compute_col="attrition")
    domain_df = cumulative_risk_by_domain(domain_df)
    domain_deltas, academia_deltas = compute_deltas(domain_df, empirical_M, empirical_W)
    
    # Plot Figure 1A with inset
    plot_fig1a(empirical_W, empirical_M, 
               r_max_list_W, r_max_list_M, 
               r_min_list_W, r_min_list_M, 
               domain_deltas, academia_deltas
              )
    
    # Repeat for promotion
    df["promotion_asst"] = (df.event == "promotion") & (df.Rank == "Assistant Professor")
    df["promotion_assoc"] = (df.event == "promotion") & (df.Rank == "Associate Professor")
    
    # Empirical promotion rates
    empirical_p1 = compute_annual_risk(df, taxonomy_col="Academia", compute_col="promotion_asst")
    empirical_p2 = compute_annual_risk(df, taxonomy_col="Academia", compute_col="promotion_assoc")
    
    empirical_W_p1 = empirical_p1[empirical_p1.Gender == "Female"]
    empirical_M_p1 = empirical_p1[empirical_p1.Gender == "Male"]
    empirical_W_p2 = empirical_p2[empirical_p2.Gender == "Female"]
    empirical_M_p2 = empirical_p2[empirical_p2.Gender == "Male"]
    
    # Perform bootstrapping over faculty careers to obtain error bounds
    num_iters = 1000
    fig1b_p1_iterations = {}
    fig1b_p2_iterations = {}
    
    for i in range(num_iters):
        p1_i_df = bootstrapping_iteration(df, people, taxonomy_col="Academia", compute_col="promotion_asst")
        p2_i_df = bootstrapping_iteration(df, people, taxonomy_col="Academia", compute_col="promotion_assoc")
        fig1b_p1_iterations[i] = p1_i_df
        fig1b_p2_iterations[i] = p2_i_df
    
    p1_max_list_W, p1_min_list_W = get_bounds(fig1b_p1_iterations, gender="Female", pct_min=2.5, pct_max=97.5)
    p1_max_list_M, p1_min_list_M = get_bounds(fig1b_p1_iterations, gender="Male", pct_min=2.5, pct_max=97.5)
    p2_max_list_W, p2_min_list_W = get_bounds(fig1b_p2_iterations, gender="Female", pct_min=2.5, pct_max=97.5)
    p2_max_list_M, p2_min_list_M = get_bounds(fig1b_p2_iterations, gender="Male", pct_min=2.5, pct_max=97.5)
    
    # Plot Figure 1B
    plot_fig1b(empirical_W_p1, empirical_M_p1,
               empirical_W_p2, empirical_M_p2,
               p1_max_list_W, p1_max_list_M,
               p1_min_list_W, p1_min_list_M,
               p2_max_list_W, p2_max_list_M,
               p2_min_list_W, p2_min_list_M)
    
    
    