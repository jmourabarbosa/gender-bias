import pandas as pd
import numpy as np

pd.options.mode.chained_assignment = None  # default='warn'

import statsmodels.api as sm
import scipy.stats as st
from scipy.stats import pearsonr

import matplotlib.pyplot as plt
import seaborn as sns

custom_params = {"axes.spines.right": False, 
                 "axes.spines.top": False,
                 "figure.figsize":(12,8),
                 'xtick.bottom': True,
                 'ytick.left': True}
sns.set_theme(style="white", rc=custom_params)

categories_map = {'productivity_reason': 'work', 
                  'funding_reason': 'work',
                  'topics_reason': 'work',
                  'recognition_reason': 'work',
                  'salary_reason': 'work',
                  'acceptance_reason': 'work',
                  'admin_reason': 'work',
                  'caring_reason': 'work_life',
                  'partner_reason': 'work_life',
                  'hobbies_reason': 'work_life',
                  'hours_reason': 'work_life',
                  'personal_reason': 'work_life',
                  'leadership_reason': 'culture',
                  'prove_reason': 'culture',
                  'belongdept_reason': 'culture',
                  'belonginst_reason': 'culture',
                  'belongfield_reason': 'culture',
                  'harassment_reason': 'culture',
                  'discrimination_reason': 'culture',
                  'competition_reason': 'culture'}

category_sizes = {"work": 7,
                  "work_life": 5, 
                  "culture": 8}

def count_reasons(row):
    """
    Count the number of reasons each person marked for leaving their job or retiring.
    """
    reason_columns = ['productivity_reason', 'funding_reason', 'topics_reason', 
                      'recognition_reason', 'salary_reason', 'acceptance_reason', 'admin_reason',
                      'caring_reason', 'partner_reason', 'hobbies_reason', 'hours_reason',
                      'personal_reason',
                      'leadership_reason', 'prove_reason', 'belongdept_reason', 'belonginst_reason',
                      'belongfield_reason', 'harassment_reason', 'discrimination_reason', 'competition_reason']
    
    num_reasons = 0
    for r in reason_columns:
        if row[r] == 'Contributed to leaving my job':
            num_reasons += 1

    return num_reasons

def create_reason_df(reason_df, groupby_col="career_age", fillna=False):
    """
    Category-weighted Method
    For each reason someone gives, that reason's weight depends on the size of the category   
    - Professional: 7
    - WL: 5
    - Climate: 8

    **Example**    
    - 2 reasons for work: 2/7
    - 2 reasons for WL: 2/5
    - 2 reasons for climate: 2/8
    - This person's decision to leave their job was majority due to a lack of work-life balance

    Percentages are created by dividing by the person's sum of reason weights
    """
    
    id_vars = ['ResponseId','gender', 'group','gave_reasons']
    if groupby_col != "" and groupby_col != "group":
        id_vars += [groupby_col]
    to_plot = pd.melt(reason_df, id_vars=id_vars, 
                      value_vars=['productivity_reason', 'funding_reason', 'topics_reason', 
                      'recognition_reason', 'salary_reason', 'acceptance_reason', 'admin_reason',
                      'caring_reason', 'partner_reason', 'hobbies_reason', 'hours_reason', 'personal_reason',
                      'leadership_reason', 'prove_reason', 'belongdept_reason', 'belonginst_reason',
                      'belongfield_reason', 'harassment_reason', 'discrimination_reason', 'competition_reason'])
    
    to_plot['category'] = to_plot['variable'].map(categories_map)
    to_plot = to_plot[(to_plot.value == "Contributed to leaving my job")]

    # Compute reason weights
    def compute_category_reason_weight(row):
        category = row.category
        denom = category_sizes[category]
        weight = 1 / denom
        return weight
    
    to_plot["reason_weight"] = to_plot.apply(compute_category_reason_weight, axis=1)

    # Divide (norm) by the sum of that person's reason weights
    denominators = dict(to_plot.groupby(["ResponseId"])["reason_weight"].sum())
    
    def compute_normed_reason_weight(row):
        weight = row.reason_weight
        rid = row.ResponseId
        denom = denominators[rid]
        normed = weight / denom
        return normed
    
    to_plot["reason_weight_normed"] = to_plot.apply(compute_normed_reason_weight, axis=1)
    
    # We need:
    # (1) the sum of reason weights for each gender and category [count] 
    # (2) the sum of reason weights for each gender [nobs]
    
    # Plot separately by gender
    women_to_plot = to_plot[to_plot.gender == "Woman"]
    men_to_plot = to_plot[to_plot.gender == "Man"]

    if groupby_col != "":
        women_df = women_to_plot.groupby([groupby_col, "category"])["reason_weight_normed"].sum().reset_index(name="count")
        women_df_nobs = women_to_plot.groupby(groupby_col)["ResponseId"].nunique().to_dict()    
        women_df["nobs"] = women_df[groupby_col].map(women_df_nobs)
        women_df["percentage"] = women_df["count"] / women_df["nobs"]

        men_df = men_to_plot.groupby([groupby_col, "category"])["reason_weight_normed"].sum().reset_index(name="count")
        men_df_nobs = men_to_plot.groupby(groupby_col)["ResponseId"].nunique().to_dict()    
        men_df["nobs"] = men_df[groupby_col].map(men_df_nobs)
        men_df["percentage"] = men_df["count"] / men_df["nobs"]
        
    else:
        women_df = women_to_plot.groupby(["category"])["reason_weight_normed"].sum().reset_index(name="count")
        women_df_nobs = women_to_plot["ResponseId"].nunique()  
        women_df["nobs"] = [women_df_nobs] * len(women_df)
        women_df["percentage"] = women_df["count"] / women_df["nobs"]

        men_df = men_to_plot.groupby(["category"])["reason_weight_normed"].sum().reset_index(name="count")
        men_df_nobs = men_to_plot["ResponseId"].nunique()  
        men_df["nobs"] = [men_df_nobs] * len(men_df)
        men_df["percentage"] = men_df["count"] / men_df["nobs"]
    
    if groupby_col == "career_age":
        # add empty rows (with nan) to each df for missing values
        df_to_plot_W = pd.DataFrame(columns=[groupby_col, "category", "percentage"])
        df_to_plot_M = pd.DataFrame(columns=[groupby_col, "category", "percentage"])

        for category in ["work", "work_life", "culture"]:
            subdf_W = women_df[(women_df.category == category)]
            subdf_M = men_df[(men_df.category == category)]
            new_index = pd.Index([x for x in range(1,46)], name=groupby_col)

            subdf_W = subdf_W.set_index(groupby_col).reindex(new_index).reset_index()
            subdf_M = subdf_M.set_index(groupby_col).reindex(new_index).reset_index()

            # fill names
            subdf_W.category = [category] * 45
            subdf_M.category = [category] * 45

            if fillna:
                subdf_W = subdf_W.fillna(0)
                subdf_M = subdf_M.fillna(0)

            df_to_plot_W = df_to_plot_W.append(subdf_W, ignore_index=True)
            df_to_plot_M = df_to_plot_M.append(subdf_M, ignore_index=True)

        return df_to_plot_W, df_to_plot_M
    
    else:
        return women_df, men_df

def bootstrap_reasons_iteration(df):
    """
    Bootstrap reasons to create confidence intervals
    
    For each iteration:
    - Randomly select N number of people with replacement
    - Compute create_reason_df like normal and get the percentages 
    """
    reason_df = df[df.gave_reasons == 1]
    left_df = reason_df[reason_df.group.isin(["left","retired"])]
    denoms = left_df.groupby(["group"])["gender"].value_counts()

    iteration_df = pd.DataFrame({})
    for group in ["left", "retired"]:
        for gender in ["Man", "Woman"]:
            n = denoms[group][gender]
            
            # Randomly select N number of people with replacement
            subgroup_df = left_df[(left_df.group == group) & (left_df.gender == gender)]
            sample_df = subgroup_df.sample(n, replace=True)
            iteration_df = pd.concat([iteration_df, sample_df]).reset_index(drop=True)
            iteration_df["ResponseId"] = list([i for i in range(len(iteration_df))])

    # Run the reason analysis
    women_df, men_df = create_reason_df(iteration_df, groupby_col="group")
    women_df["gender"] = ["Woman"] * len(women_df)
    men_df["gender"] = ["Man"] * len(men_df)
    combined_df = pd.concat([women_df,men_df]).reset_index(drop=True)
    
    return combined_df

def bootstrapping_procedure(df, num_iters=1000):
    """
    Run bootstrapping iteration num_iters times and collect the results
    """
    scores = {
        "left": {
            "work": {"Woman": [], "Man": []},
            "work_life": {"Woman": [], "Man": []},
            "culture": {"Woman": [], "Man": []},
        },
        "retired": {
            "work": {"Woman": [], "Man": []},
            "work_life": {"Woman": [], "Man": []},
            "culture": {"Woman": [], "Man": []},
        }
    }

    for i in range(num_iters):
        idf = bootstrap_reasons_iteration(df)
        for group in ["left", "retired"]:
            for category in ["work", "work_life", "culture"]:
                for gender in ["Woman", "Man"]:
                    p = idf[(idf.group == group) & (idf.gender == gender) & (idf.category == category)].percentage.item()
                    scores[group][category][gender].append(p)
    return scores

def compute_CIs(scores, combined_df):
    """
    Compute CIs using the results of the bootstrapping scores
    """
    # get percentiles
    def compute_bootstrap_lower(row):
        c = row['category'] 
        g = row['gender']
        group = row["group"]
        p_list = np.sort(scores[group][c][g]) 
        lower = np.percentile(p_list, 2.5)
        return lower

    def compute_bootstrap_upper(row):
        c = row['category'] 
        g = row['gender']
        group = row["group"]
        p_list = np.sort(scores[group][c][g])
        upper = np.percentile(p_list, 97.5)
        return upper

    combined_df["lower_ci"] = combined_df.apply(compute_bootstrap_lower, axis=1)
    combined_df["upper_ci"] = combined_df.apply(compute_bootstrap_upper, axis=1)
    return combined_df

def create_impact_df(df, y_col, groupby_cols=["career_age","gender"]):
    """
    Reshape data to create Figures 4B-D (impacts).
    """
    final_df = df.groupby(groupby_cols)[y_col].sum().reset_index(name="count")
    final_df_nobs = df.groupby(groupby_cols)["ResponseId"].nunique().to_dict()

    def map_nobs(row):
        a = row[groupby_cols[0]]
        g = row.gender
        s = row.STEM
        nobs = final_df_nobs[(a, g, s)]
        return nobs

    final_df["nobs"] = final_df.apply(map_nobs, axis=1)
    final_df["percent"] = final_df["count"] / final_df["nobs"]

    return final_df

def err_bars(df):
    import statsmodels.stats.proportion as stp
    
    ci_lower, ci_upper = stp.proportion_confint(
        count = df["count"].item(),
        nobs = df["nobs"].item(),
        alpha=0.05) 
    
    CI_length = (ci_upper - ci_lower) / 2 # this is the +/-, y_err
    return CI_length 


# PLOTTING
def plot_fig4a(df):
    df["category"] = pd.Categorical(df["category"], categories=["work", "work_life", "culture"],ordered=True)
    df = df.sort_values("category", ascending=True)
    
    df["gender_group"] = df["gender"] + " " + df["group"]
    
    df["gender_group"] = df["gender_group"].map({"Woman left": "Women who left",
                                                 "Woman retired": "Women who retired",
                                                 "Man left": "Men who left",
                                                 "Man retired": "Men who retired"})
    
    fig, ax = plt.subplots(figsize=(7,5)) 
    g = sns.barplot(ax=ax, x="category", y="percentage", hue="gender_group",
                    palette=['turquoise', 'turquoise', 'grey', 'grey'],
                    order=["work", "work_life", "culture"],
                    data=df)

    # Define some hatches
    hatches = ['', '', '', '///', '///', '///', '', '', '', '///', '///', '///']

    # Loop over the bars
    for i, b in enumerate(g.patches):
        # Set a different hatch for each bar
        b.set_hatch(hatches[i])
    
    ax.set_xticklabels(["Professional", "Work-life balance", "Climate"],fontsize=16)
    plt.ylim([0, 0.06])
    ax.set_yticks([0.0, 0.1, 0.2, 0.3, 0.4, 0.5])
    ax.set_yticklabels([0.0, 0.1, 0.2, 0.3, 0.4, 0.5],fontsize=14)
    plt.ylabel('Fraction of reasons selected (weighted)', fontsize=16, labelpad=10)
    plt.xlabel('')

    x_coords = [p.get_x() + 0.5*p.get_width() for p in ax.patches]
    x_coords.sort()
    y_coords = list(df["percentage"])

    asymmetric_error = [df["percentage"] - df["lower_ci"], df["upper_ci"] - df["percentage"]]
    ax.errorbar(x=x_coords, y=y_coords, yerr=asymmetric_error, capsize=6, fmt='.', color='black')

    g.legend_.set_title(None)
    plt.legend(loc='upper left', frameon=False, bbox_to_anchor=(0,1.15), #(0,1.1), #(0, 1.05), 
               ncol=2) 
    plt.setp(ax.get_legend().get_texts(), fontsize='14')

    plt.tight_layout()
    fig.savefig("figures/fig4a.pdf", dpi=300)
    
def plot_fig4b(df, group_col, palette, pad=True, fillna=True, frac=0.25, scatter=False, err=False):
    age_order = ['1-10', '11-20', '21-30', '31-40']
    age_index = {'1-10': 1, '11-20': 2, '21-30': 3, '31-40': 4}
    
    fig, (ax_prof, ax_balance, ax_climate) = plt.subplots(1, 3, figsize=(9,5), sharey=True)
    for ax, col in zip([ax_prof, ax_balance, ax_climate], ["prof_rank_high", "balance_rank_high", "climate_rank_high"]):
        for g in set(df[group_col]):
            subdf_W = df[(df.category == col) & (df.gender == "Woman") & (df[group_col] == g)]
            subdf_M = df[(df.category == col) & (df.gender == "Man") & (df[group_col] == g)]

            subdf_W["age_group"] = pd.Categorical(subdf_W["age_group"], categories=age_order, ordered=True)
            subdf_M["age_group"] = pd.Categorical(subdf_M["age_group"], categories=age_order, ordered=True)
            subdf_W = subdf_W.sort_values("age_group", ascending=True)
            subdf_M = subdf_M.sort_values("age_group", ascending=True)

            subdf_W["age_index"] = subdf_W["age_group"].map(age_index)
            subdf_M["age_index"] = subdf_M["age_group"].map(age_index)

            ax.plot(subdf_W["age_group"], subdf_W["percent"], color={"STEM":"teal", "Non-STEM":"#7de3e3"}[g], linestyle="solid", linewidth=3)
            ax.plot(subdf_M["age_group"], subdf_M["percent"], color={"STEM":"#4d4d4f", "Non-STEM":"lightgrey"}[g], linestyle="solid", linewidth=3)
            
            sns.scatterplot(ax=ax, data=subdf_W, x="age_group", y="percent",
                            hue=group_col, palette={"STEM":"teal", "Non-STEM":"#7de3e3"}, 
                            marker="^", s=90, edgecolor="black", linewidth=0.2,
                            zorder=20)
            sns.scatterplot(ax=ax, data=subdf_M, x="age_group", y="percent",
                            hue=group_col, palette={"STEM":"#4d4d4f", "Non-STEM":"lightgrey"}, 
                            marker="o", s=70, edgecolor="black", linewidth=0.2,
                            zorder=20)

            if err:
                women_df = subdf_W; men_df = subdf_M;
                
                # plot max line
                sns.lineplot(ax=ax, data=women_df, x="age_group", y="ci_upper", 
                             color={"STEM":"teal", "Non-STEM":"paleturquoise"}[g],
                             linewidth=0.25, alpha=0.2)
                sns.lineplot(ax=ax, data=men_df, x="age_group", y="ci_upper", 
                             color={"STEM":"#4d4d4f", "Non-STEM":"lightgrey"}[g],
                             linewidth=0.25, alpha=0.2)

                # plot min line
                sns.lineplot(ax=ax, data=women_df, x="age_group", y="ci_lower", 
                             color={"STEM":"teal", "Non-STEM":"paleturquoise"}[g],
                             linewidth=0.25, alpha=0.2)
                sns.lineplot(ax=ax, data=men_df, x="age_group", y="ci_lower", 
                             color={"STEM":"#4d4d4f", "Non-STEM":"lightgrey"}[g],
                             linewidth=0.25, alpha=0.2)

                # fill between
                if g == "STEM":
                    ax.fill_between(women_df["age_group"], women_df["ci_upper"], women_df["percent"], 
                                    color="teal", alpha=0.15)
                    ax.fill_between(women_df["age_group"], women_df["percent"], women_df["ci_lower"], 
                                    color="teal", alpha=0.15)
                else:
                    ax.fill_between(women_df["age_group"], women_df["ci_upper"], women_df["percent"], 
                                    color="paleturquoise", alpha=0.4)
                    ax.fill_between(women_df["age_group"], women_df["percent"], women_df["ci_lower"], 
                                    color="paleturquoise", alpha=0.4)

                ax.fill_between(men_df["age_group"], men_df["ci_upper"], men_df["percent"], 
                                color={"STEM":"#4d4d4f", "Non-STEM":"lightgrey"}[g], alpha=0.2)
                ax.fill_between(men_df["age_group"], men_df["percent"], men_df["ci_lower"], 
                                color={"STEM":"#4d4d4f", "Non-STEM":"lightgrey"}[g], alpha=0.2)
            ax.set_ylim([0, 0.5])
            ax.set_xticklabels(["1-10", "11-20", "21-30", "31-40"], fontsize=13)
            ax.set_yticklabels([0.0, 0.1, 0.2, 0.3, 0.4, 0.5], fontsize=13)
            ax.set_xlabel(r'Career age, $t$', fontsize=15) #16)
        ax_prof.set_ylabel("Fraction of current faculty", fontsize=15) #16)
        ax_prof.set_title("Professional", fontsize=15,  y=1.05)
        ax_balance.set_title("Work-life balance", fontsize=15,  y=1.05)
        ax_climate.set_title("Climate", fontsize=15,  y=1.05)
    
        ax.legend([],[], frameon=False)
    
    plt.tight_layout()
    fig.savefig("figures/fig4b.pdf", dpi=300)

    
if name == "__main__":
    # Load survey data
    df = load_data.load_survey()
    
    # -99 is the code for "seen but unanswered" --> recode these as NA
    for col in categories_map.keys():
        df[col] = df[col].replace('-99', np.nan)
        
    # Count how many reasons each former faculty member indicated for leaving
    df['num_reasons'] = df.apply(count_reasons, axis=1)
    
    # Reasons former faculty left
    reason_df = stress_df[stress_df.gave_reasons == 1]
    reason_df = reason_df[(reason_df.career_age > 0) & (reason_df.career_age <= 45)]
    left_df = reason_df[reason_df.group.isin(["left","retired"])]
    women_df, men_df = create_reason_df(left_df, groupby_col="group")
    women_df["gender"] = ["Woman"] * len(women_df)
    men_df["gender"] = ["Man"] * len(men_df)
    combined_df = pd.concat([women_df,men_df]).reset_index(drop=True)

    # Use bootstrapping to get CIs
    scores = bootstrapping_procedure(combined_df, num_iters=1000)
    combined_df = compute_CIs(scores, combined_df)
    
    # Plot figure 4A
    plot_fig4a(combined_df)
    
    # Reasons current faculty would leave
    impact_df = df[(df.career_age > 0) & (df.career_age <= 40)]
    impact_df["climate_rank_high"] = np.where(impact_df["climate_rank"] == 3, 1, 0)
    impact_df["prof_rank_high"] = np.where(impact_df["prof_rank"] == 3, 1, 0)
    impact_df["balance_rank_high"] = np.where(impact_df["balance_rank"] == 3, 1, 0)
     
    age_col = "career_age"
    final_df = pd.DataFrame({})
    for col in ["climate_rank_high", "prof_rank_high", "balance_rank_high"]:
        impact_df_to_plot = create_impact_df(impact_df, y_col=col, groupby_cols=[age_col,"gender", "STEM"])
        impact_df_to_plot["category"] = [col] * len(impact_df_to_plot)
        final_df = pd.concat([final_df, impact_df_to_plot])
    
    # group into career age groups
    age_groups = {1: '1-10', 2: '1-10', 3: '1-10', 4: '1-10', 5:'1-10',
                  6: '1-10', 7: '1-10', 8: '1-10', 9: '1-10', 10: '1-10',
                  11: '11-20', 12: '11-20', 13: '11-20', 14: '11-20', 15: '11-20',
                  16: '11-20', 17: '11-20', 18: '11-20', 19: '11-20', 20: '11-20',
                  21: '21-30', 22: '21-30', 23: '21-30', 24: '21-30', 25: '21-30',
                  26: '21-30', 27: '21-30', 28: '21-30', 29: '21-30', 30: '21-30',
                  31: '31-40', 32: '31-40', 33: '31-40', 34: '31-40', 35: '31-40',
                  36: '31-40', 37: '31-40', 38: '31-40', 39: '31-40', 40: '31-40'}

    final_df["age_group"] = final_df["career_age"].map(age_groups)
    
    age_group_df = final_df.groupby(["gender", "STEM", "age_group", "category"])["count", "nobs"].sum().reset_index()
    age_group_df["percent"] = age_group_df["count"] / age_group_df["nobs"]
    
    age_col = "age_group"
    def compute_CIs_impacts(row):
        s = row['STEM']
        g = row['gender']
        a = row[age_col]
        c = row['category'] 
 
        df = age_group_df[(age_group_df.gender == g) & (age_group_df.category == c) & 
                          (age_group_df[age_col] == a) & (age_group_df.STEM == s)] 
        ci = err_bars(df)
        return ci

    age_group_df['ci'] = age_group_df.apply(compute_CIs_impacts, axis=1)
    age_group_df['ci_upper'] = age_group_df["percent"] + age_group_df["ci"]
    age_group_df['ci_lower'] = age_group_df["percent"] - age_group_df["ci"]
    
    plot_fig4b(age_group_df, group_col="STEM", palette={}, err=True)
    
    

