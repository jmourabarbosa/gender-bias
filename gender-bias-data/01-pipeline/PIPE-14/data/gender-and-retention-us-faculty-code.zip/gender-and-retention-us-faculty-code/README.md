#gender-and-retention-us-faculty-code
This repository includes the code used to generate the results in `Gender and retention patterns among U.S. faculty`.

Because we are unable to make the primary data available, this repository is non-functional. 

`scripts` contains several helper files that load and preprocess the data. 

Four files were used to run each of the four main analyses:
- `retention_rates.py`: generates Figures 1A-B, the annual and cumulative retention and promotion rates by career age and gender across academia.
- `retention_odds.py`: generates Figures 2A-D, the logistic regression that calculates the odds of leaving adjusting for gender, career age, institutional prestige, and PhD training, across (1) academia, (2) broad domains of study, and (3) using fixed effects for academic field (department).
- `survey_push_pull.py`: generates Figures 3A-D, the rates of people who felt pushed/pulled across gender, STEM and career age, and the logistic regression that calculate the odds of feeling pushed/pulled adjusting for gender, STEM, prestige, and career age.
- `survey_reasons.py`: generates Figures 4A-D, the reasons former faculty marked as contributing to their decisions to leave or retire, and the impact various categories of reasons current faculty marked as having a "major impact" on a potential decision to leave their job.    