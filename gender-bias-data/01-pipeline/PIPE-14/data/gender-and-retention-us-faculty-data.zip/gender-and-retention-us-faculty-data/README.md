# gender-and-retention-us-faculty-data
This repository contains the data described in `Gender and retention patterns among U.S. faculty`.

There are two datasets included here:

1. Aggregated administrative employment records (found at `data/employment_records.csv`)
2. Aggregated survey responses (found at `data/survey_responses.csv`)

The full survey questionnaire can be found at `questionnaire.pdf`

## Using the data

Due to privacy concerns, we have designed the two aggregated datasets to be unable to be linked together. However, aggregated respondent groups may be linked across datasets (e.g., current women faculty in STEM with career ages 1-10 at institutions in prestige decile 1).

## Employment records

The csv containing the employment records has the following columns:

- `gender`: String. Either "Women" or "Men". Derived from name-gender associations (SI Section S1C).
- `rank`: String. Either "Assistant Professor", "Associate Professor", or "Professor" (Full Professor)
- `domain`: String. One of ["Natural Sciences", "Humanities", "Social Sciences", "Health", "Mathematics and Computing","Medicine", "Engineering","Business","Education","Journalism, Media, Communication","Public Administration and Policy"]
- `career_age`: Integer. Years since they received their PhD. Ranges from 1 to 40. 
- `prestige_decile`: Integer. Institutions have a unique prestige ranking that has been binned into deciles 1-10 for privacy, where 10 is the most prestigious decile and 1 is the least prestigious.
- `us_phd`: Integer. This variable is 1 for faculty who obtained their doctoral degree in the U.S., and 0 for faculty who obtained their doctoral degree outside of the U.S.
- `year`: Integer. The year of employment records, ranging from 2011-2019. Events in each year y signal what occurred between year y and y+1. For example, in year 2011, people who experienced attrition existed in 2011 but not in 2012. As another example, people who experienced promotion in 2019 were one rank in 2019 and a higher rank in 2020. 
- `event`: String. Our dataset has three mutually exclusive events: (1) "attrition", faculty who were employed in year y but left in year y+1, (2) "promotion", faculty who were assistant professors in year y and associate professors in year y+1 or faculty who were associate professors in year y and full professors in year y+1, and (3) "retention", faculty who did not leave and were not promoted. Adding the three gives the total number of people in that subgroup in a particular year.
- `count`: Integer. Number of people in the given subgroup who experienced the given event in year y+1. 

For example, for a row with this information:

- `gender`: "Women"
- `rank`: "Assistant Professor"
- `domain`: "Social Sciences"
- `career_age`: 10.0 
- `prestige_decile`: 10.0
- `us_phd`: 1 
- `year`: 2019 
- `event`: "attrition"
- `count`: 5

means that in 2020, 5 women assistant professors in the social sciences who were employed at the most prestigious decile of universities in the U.S. in 2019 and who obtained their doctoral degrees in the U.S. 10 years prior (in 2009), left their positions.

## Survey responses

Missing data are included for age_group, prestige_decile and STEM as different analyses in the paper use various groupings of the data. Non-binary faculty are excluded in the public dataset due to privacy concerns. 

The csv containing the survey records has the following columns:

- `group`: String. Either "switched" (faculty who switched institutions), "left" (faculty who left academia", "retired" (faculty who retired), or "current" (faculty who have remained in their positions since they started or since 2009, whichever is later).
- `gender`: String. Either "Woman" or "Man". 
- `age_group`: String. Either "1-10", "10-20", "20-30", "30-40", or NA. Binned from career_age, years since they received their PhD.
- `prestige_decile`: Integer. Institutions have a unique prestige ranking that has been binned into deciles 1-10 for privacy, where 10 is the most prestigious decile and 1 is the least prestigious.
- `STEM`: Integer. Either "STEM", "Non-STEM", or NA. Assigned using their employing domain. A small amount of faculty whose primary appointments encompass STEM and Non-STEM fields are marked as NA. 
- `subgroup_total`: Integer. Number of people in the given [group x gender x age_group x prestige_decile x STEM] subgroup.
- `only_push`: Integer. Number of people who said they would or did leave their jobs only due to a push.
- `only_pull`: Integer. Number of people who said they would or did leave their jobs only due to a pull.
- `push_and_pull`: Integer. Number of people who said they would or did leave their jobs due to both a push and a pull.
- `neither_push_or_pull`: Integer. Number of people who said they would not consider leaving their jobs or that they only left because they wanted to retire.
- `prof_major_impact`: Integer. Number of people who said professional reasons would or did have a "major impact" on their decisions to leave their job.
- `balance_major_impact`: Integer. Number of people who said work-life balance reasons would or did have a "major impact" on their decisions to leave their job.
- `climate_major_impact`: Integer. Number of people who said workplace climate reasons would or did have a "major impact" on their decisions to leave their job.
- `better_job_major_impact`: Integer. Number of people who said a better job would or did have a "major impact" on their decisions to leave their job.
- `num_prof_reasons`: Integer. Total number of professional reasons people selected as reasons for leaving, retiring, or switching jobs. [unweighted]
- `num_balance_reasons`: Integer. Total number of work-life balance reasons people selected as reasons for leaving, retiring, or switching jobs. [unweighted]
- `num_climate_reasons`: Integer. Total number of workplace climate reasons people selected as reasons for leaving, retiring, or switching jobs. [unweighted]

Only unweighted and aggregated reasons for leaving are given here, as the weighted scores used in Figure 4A are calculated from individual-level reasons, and weighted by the number of reasons the individual gave and the number of reasons in each category. As a result, the results vary slightly from the results in the paper but are still qualitatively similar. 
